#!/usr/bin/env node
/**
 * ZeroVaultProxy CA Console — a local, user-friendly interface for managing
 * device certificates. Runs ON THE CA MACHINE (where ca.key lives), binds
 * to 127.0.0.1 ONLY, and shells out to certs/generate-certs.sh. Nothing
 * here ever exposes the CA to the network — this is a control panel for
 * the offline CA workflow, not a service.
 *
 * Usage:
 *   cd tools/ca-console
 *   CA_KEY_PASS=<ca key passphrase> node server.js
 *   -> open the printed http://127.0.0.1:8470/?token=... URL
 *
 * Security posture:
 *   - listens on 127.0.0.1 only; refuses to start on 0.0.0.0
 *   - random session token per start, required on every request
 *   - device names validated [a-z0-9-]{1,64}; all exec via execFile (no shell)
 *   - .p12 bundles are offered for download once, then deleted on request
 *
 * Zero dependencies (Node 18+).
 */
'use strict';

const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { execFile } = require('child_process');

const PORT = Number(process.env.PORT || 8470);
const CERTS_DIR = process.env.CERTS_DIR || path.join(__dirname, '..', '..', 'certs');
const SCRIPT = path.join(CERTS_DIR, 'generate-certs.sh');
const TOKEN = crypto.randomBytes(24).toString('hex');

if (!process.env.CA_KEY_PASS) {
  console.error('Set CA_KEY_PASS (the CA key passphrase) before starting.');
  process.exit(1);
}
if (!fs.existsSync(SCRIPT)) {
  console.error(`generate-certs.sh not found at ${SCRIPT} (set CERTS_DIR)`);
  process.exit(1);
}

const NAME_RE = /^[a-z0-9-]{1,64}$/;

function sh(args, input) {
  return new Promise((resolve, reject) => {
    const child = execFile('bash', [SCRIPT, ...args], {
      cwd: CERTS_DIR,
      env: { ...process.env },
      timeout: 30_000,
    }, (err, stdout, stderr) => err ? reject(new Error(stderr || err.message)) : resolve(stdout));
    if (input !== undefined) { child.stdin.write(input); child.stdin.end(); }
  });
}

function openssl(args) {
  return new Promise((resolve, reject) => {
    execFile('openssl', args, { cwd: CERTS_DIR, timeout: 10_000 },
      (err, stdout, stderr) => err ? reject(new Error(stderr || err.message)) : resolve(stdout));
  });
}

/** Serial numbers revoked according to index.txt (openssl ca database). */
function revokedSerials() {
  const idx = path.join(CERTS_DIR, 'index.txt');
  if (!fs.existsSync(idx)) return new Set();
  return new Set(fs.readFileSync(idx, 'utf8').split('\n')
    .filter((l) => l.startsWith('R\t'))
    .map((l) => l.split('\t')[3]).filter(Boolean));
}

async function certInfo(file) {
  const out = await openssl(['x509', '-in', file, '-noout', '-subject', '-enddate', '-serial']);
  const cn = (out.match(/CN\s*=\s*([^\n\/,]+)/) || [])[1]?.trim();
  const notAfter = new Date((out.match(/notAfter=(.+)/) || [])[1]);
  const serial = (out.match(/serial=([0-9A-F]+)/i) || [])[1];
  return { cn, notAfter, serial };
}

async function state() {
  const revoked = revokedSerials();
  const devices = [];
  for (const f of fs.readdirSync(CERTS_DIR)) {
    const m = f.match(/^client-(.+)\.crt$/);
    if (!m) continue;
    const info = await certInfo(f);
    const days = Math.floor((info.notAfter - Date.now()) / 86400000);
    devices.push({
      name: m[1],
      serial: info.serial,
      expires: info.notAfter.toISOString().slice(0, 10),
      daysLeft: days,
      status: revoked.has(info.serial) ? 'revoked' : days < 0 ? 'expired' : days < 30 ? 'expiring' : 'active',
      p12: fs.existsSync(path.join(CERTS_DIR, `client-${m[1]}.p12`)),
    });
  }
  devices.sort((a, b) => a.name.localeCompare(b.name));
  let server = null;
  if (fs.existsSync(path.join(CERTS_DIR, 'server.crt'))) {
    const info = await certInfo('server.crt');
    server = { cn: info.cn, expires: info.notAfter.toISOString().slice(0, 10),
               daysLeft: Math.floor((info.notAfter - Date.now()) / 86400000) };
  }
  let crl = null;
  const crlPath = path.join(CERTS_DIR, 'crl.pem');
  if (fs.existsSync(crlPath)) {
    crl = { updated: fs.statSync(crlPath).mtime.toISOString().replace('T', ' ').slice(0, 16),
            revoked: revoked.size };
  }
  return { caReady: fs.existsSync(path.join(CERTS_DIR, 'ca.crt')), server, crl, devices };
}

async function readBody(req) {
  const chunks = [];
  for await (const c of req) { chunks.push(c); if (Buffer.concat(chunks).length > 65536) throw new Error('too large'); }
  return JSON.parse(Buffer.concat(chunks).toString() || '{}');
}

function json(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  const token = url.searchParams.get('token') || req.headers['x-token'];
  if (token !== TOKEN) return json(res, 401, { error: 'bad or missing token — restart the console and use the printed URL' });

  try {
    if (req.method === 'GET' && url.pathname === '/') {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      return res.end(PAGE.replaceAll('__TOKEN__', TOKEN));
    }
    if (req.method === 'GET' && url.pathname === '/api/state') return json(res, 200, await state());

    if (req.method === 'POST' && url.pathname === '/api/init') {
      const { host } = await readBody(req);
      if (!/^[A-Za-z0-9.-]{1,253}$/.test(host || '')) return json(res, 400, { error: 'invalid hostname/IP' });
      await sh(['init', host]);
      return json(res, 200, { ok: true });
    }
    if (req.method === 'POST' && url.pathname === '/api/enroll') {
      const { name, p12pass } = await readBody(req);
      if (!NAME_RE.test(name || '')) return json(res, 400, { error: 'device name must be [a-z0-9-]' });
      if (!p12pass || p12pass.length < 6) return json(res, 400, { error: 'p12 password: 6+ characters' });
      if (fs.existsSync(path.join(CERTS_DIR, `client-${name}.crt`))) return json(res, 409, { error: 'device already exists' });
      await sh(['client', name], `${p12pass}\n${p12pass}\n`);
      return json(res, 200, { ok: true });
    }
    if (req.method === 'POST' && url.pathname === '/api/revoke') {
      const { name } = await readBody(req);
      if (!NAME_RE.test(name || '')) return json(res, 400, { error: 'invalid name' });
      await sh(['revoke', name]);
      return json(res, 200, { ok: true });
    }
    if (req.method === 'GET' && url.pathname.startsWith('/download/')) {
      const name = url.pathname.slice('/download/'.length).replace(/\.p12$/, '');
      if (!NAME_RE.test(name)) return json(res, 400, { error: 'invalid name' });
      const file = path.join(CERTS_DIR, `client-${name}.p12`);
      if (!fs.existsSync(file)) return json(res, 404, { error: 'no bundle (already collected?)' });
      res.writeHead(200, {
        'content-type': 'application/x-pkcs12',
        'content-disposition': `attachment; filename="client-${name}.p12"`,
      });
      return fs.createReadStream(file).pipe(res);
    }
    if (req.method === 'POST' && url.pathname === '/api/delete-p12') {
      const { name } = await readBody(req);
      if (!NAME_RE.test(name || '')) return json(res, 400, { error: 'invalid name' });
      fs.rmSync(path.join(CERTS_DIR, `client-${name}.p12`), { force: true });
      return json(res, 200, { ok: true });
    }
    return json(res, 404, { error: 'not found' });
  } catch (err) {
    return json(res, 500, { error: String(err.message || err).split('\n')[0].slice(0, 300) });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('ZeroVaultProxy CA Console (localhost only)');
  console.log(`  open:  http://127.0.0.1:${PORT}/?token=${TOKEN}`);
  console.log(`  certs: ${CERTS_DIR}`);
});

/* ------------------------------ UI ------------------------------------- */
const PAGE = `<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>ZeroVaultProxy CA Console</title>
<style>
:root{--bg:#0E1330;--card:#1A2148;--line:#2D3768;--ink:#EAF0FF;--muted:#8E9BC4;--mint:#02C39A;--red:#E05555;--amber:#E0A955}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,-apple-system,sans-serif;padding:28px}
.wrap{max-width:880px;margin:0 auto}h1{font-size:22px;margin:0 0 4px;display:flex;gap:10px;align-items:center}
h1 svg{flex:none}.sub{color:var(--muted);font-size:13px;margin:0 0 24px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px 20px;margin-bottom:16px}
.card h2{font-size:15px;margin:0 0 12px}
table{width:100%;border-collapse:collapse;font-size:14px}
th{color:var(--muted);text-align:left;font-size:11px;letter-spacing:.08em;text-transform:uppercase;padding:6px 10px}
td{padding:8px 10px;border-top:1px solid var(--line)}
.chip{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600}
.chip.active{background:rgba(2,195,154,.15);color:var(--mint)}
.chip.revoked{background:rgba(224,85,85,.15);color:var(--red)}
.chip.expiring{background:rgba(224,169,85,.15);color:var(--amber)}
.chip.expired{background:rgba(142,155,196,.15);color:var(--muted)}
button,input{font:inherit;border-radius:8px;border:1px solid var(--line);background:#232B5C;color:var(--ink);padding:7px 12px}
button{cursor:pointer}button:hover{border-color:var(--muted)}
button.primary{background:var(--mint);color:#05121B;border-color:transparent;font-weight:600}
button.danger{color:var(--red)}
form{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.note{color:var(--muted);font-size:12.5px;margin-top:10px}
.kv{display:flex;gap:22px;flex-wrap:wrap;color:var(--muted);font-size:13px}
.kv b{color:var(--ink);font-weight:600}
#msg{min-height:22px;font-size:13px;margin-bottom:10px}
#msg.ok{color:var(--mint)}#msg.err{color:var(--red)}
a{color:var(--mint)}
</style></head><body><div class="wrap">
<h1><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#02C39A" stroke-width="2.2" stroke-linejoin="round"><path d="M12 2 20 6v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/></svg>ZeroVaultProxy CA Console</h1>
<p class="sub">Local certificate authority control — this page only works on the CA machine, never over the network.</p>
<div id="msg"></div>

<div class="card" id="init-card" hidden>
  <h2>Set up the certificate authority</h2>
  <form onsubmit="return init(event)">
    <input id="host" placeholder="proxy hostname or IP" required>
    <button class="primary">Create CA + server certificate</button>
  </form>
</div>

<div class="card" id="overview" hidden>
  <h2>Overview</h2>
  <div class="kv" id="kv"></div>
</div>

<div class="card">
  <h2>Enroll a device</h2>
  <form onsubmit="return enroll(event)">
    <input id="name" placeholder="device name (e.g. phone-001)" pattern="[a-z0-9-]+" required>
    <input id="p12pass" type="password" placeholder="p12 password (given to the device owner)" minlength="6" required>
    <button class="primary">Create certificate</button>
  </form>
  <div class="note">Creates a 365-day P-384 certificate and a .p12 bundle. Download it below, deliver it to the device over a trusted channel, then delete the bundle.</div>
</div>

<div class="card">
  <h2>Devices</h2>
  <table><thead><tr><th>Device</th><th>Status</th><th>Expires</th><th></th></tr></thead>
  <tbody id="rows"><tr><td colspan="4" style="color:var(--muted)">loading…</td></tr></tbody></table>
  <div class="note">Revoking regenerates <code>crl.pem</code> — copy it to the gateway's certs directory; Node/Go gateways apply it within ~60&nbsp;seconds automatically.</div>
</div>
</div>
<script>
const T='__TOKEN__';
const api=(p,opts)=>fetch(p+(p.includes('?')?'&':'?')+'token='+T,opts).then(async r=>{const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||r.status);return j});
const msg=(t,ok)=>{const m=document.getElementById('msg');m.textContent=t;m.className=ok?'ok':'err';};
async function load(){
  try{
    const s=await api('/api/state');
    document.getElementById('init-card').hidden=s.caReady;
    document.getElementById('overview').hidden=!s.caReady;
    if(s.caReady){
      const kv=[];
      if(s.server)kv.push('<span>Gateway cert: <b>'+s.server.cn+'</b> · expires '+s.server.expires+' ('+s.server.daysLeft+' d)</span>');
      kv.push('<span>Devices: <b>'+s.devices.length+'</b></span>');
      kv.push(s.crl?'<span>CRL: <b>'+s.crl.revoked+' revoked</b> · updated '+s.crl.updated+'</span>':'<span>CRL: <b>none yet</b></span>');
      document.getElementById('kv').innerHTML=kv.join('');
    }
    const rows=s.devices.map(d=>{
      const chip='<span class="chip '+d.status+'">'+d.status+'</span>';
      const dl=d.p12?'<a href="/download/'+d.name+'.p12?token='+T+'">download .p12</a> · <button onclick="delp12(\\''+d.name+'\\')">delete bundle</button> ':'';
      const rv=d.status==='revoked'?'':'<button class="danger" onclick="revoke(\\''+d.name+'\\')">revoke</button>';
      return '<tr><td><b>'+d.name+'</b></td><td>'+chip+'</td><td>'+d.expires+' <span style="color:var(--muted)">('+d.daysLeft+' d)</span></td><td style="text-align:right">'+dl+rv+'</td></tr>';
    }).join('');
    document.getElementById('rows').innerHTML=rows||'<tr><td colspan="4" style="color:var(--muted)">no devices yet — enroll the first one above</td></tr>';
  }catch(e){msg('Error: '+e.message,false)}
}
async function enroll(ev){ev.preventDefault();
  try{await api('/api/enroll',{method:'POST',body:JSON.stringify({name:name.value,p12pass:p12pass.value})});
    msg('Device "'+name.value+'" enrolled — download its .p12 below.',true);name.value='';p12pass.value='';load();
  }catch(e){msg('Enroll failed: '+e.message,false)}return false}
async function init(ev){ev.preventDefault();
  try{await api('/api/init',{method:'POST',body:JSON.stringify({host:host.value})});msg('CA created.',true);load()}
  catch(e){msg('Init failed: '+e.message,false)}return false}
async function revoke(n){if(!confirm('Revoke "'+n+'"? The device loses access within ~60s of the CRL reaching the gateway.'))return;
  try{await api('/api/revoke',{method:'POST',body:JSON.stringify({name:n})});msg('"'+n+'" revoked. Copy crl.pem to the gateway.',true);load()}
  catch(e){msg('Revoke failed: '+e.message,false)}}
async function delp12(n){try{await api('/api/delete-p12',{method:'POST',body:JSON.stringify({name:n})});msg('Bundle for "'+n+'" deleted.',true);load()}catch(e){msg(e.message,false)}}
load();setInterval(load,15000);
</script></body></html>`;
