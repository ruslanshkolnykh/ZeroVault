# Security review & threat model

> **Audit round 2 (DoD/NSS alignment)** found and fixed 7 further items —
> CNSA-grade crypto defaults (P-384/SHA-384), a FIPS operating mode, CRL
> hot-reload (revocation without restart), structured audit logging,
> connection caps, dependency pinning, and SDK input hardening. Findings
> B1–B7 and the NIST 800-53 control mapping live in **docs/COMPLIANCE.md**.

This document records the security audit of llm-proxy, what was changed as
a result, and the residual risks an operator must manage.

## Threat model

Assets: the provider API keys (on devices, in transit), the device
identities (client certs), and the proxy's availability. Adversaries: a
network attacker (sniffing/MITM/hijack), an internet scanner hitting the
port, a thief with a stolen phone or extracted client cert, and a
compromised proxy host.

The proxy is deliberately stateless: compromise of the proxy host yields
no stored credentials — only its own TLS keypair (which cannot mint device
certs; `ca.key` is offline and encrypted) and the CA *public* cert.
In-flight requests through a compromised host could still be read, which
is why host hardening below matters.

## Audit findings and fixes (all applied)

**A1 — TLS floor too low, weak ciphers possible (Node/Go/Python).**
`minVersion: TLSv1.2` with default cipher lists allowed CBC-mode and
non-PFS suites. *Fixed:* TLS 1.3 is now the default floor in all three
implementations. An explicit `TLS_MIN_VERSION=TLSv1.2` opt-out exists for
older Android devices, and that fallback is pinned to ECDHE+AEAD suites
only (AES-GCM / ChaCha20-Poly1305) — no CBC, no static-RSA key exchange,
so every session has forward secrecy: recorded traffic cannot be decrypted
later even if the server key leaks.

**A2 — No certificate revocation in Go and Python.** A stolen device cert
was irrevocable without rotating the whole CA. *Fixed:* Go parses a CRL
(`TLS_CRL`) and rejects revoked serials in `VerifyPeerCertificate`; Python
gained `run.py`, which builds the SSL context with
`VERIFY_CRL_CHECK_LEAF`; Node already supported `crl` and keeps it.
`generate-certs.sh revoke <device>` produces the CRL. Verified: a revoked
cert is refused at the handshake while a valid one still connects.

**A3 — No rate limiting or body caps.** A stolen-but-not-yet-revoked cert
(or a buggy app) could hammer upstreams or exhaust proxy memory with huge
bodies. *Fixed:* per-device token-bucket rate limiting (`RATE_LIMIT_RPM`,
`RATE_LIMIT_BURST`, keyed on the certificate CN in Node/Go and client IP
in Python — see Limitations) returning 429, and a streaming-enforced body
cap (`MAX_BODY_BYTES`, default 25 MB) returning 413. The cap is enforced
on actual bytes received, not just the Content-Length header, so chunked
bodies cannot bypass it. Bucket maps are pruned so they cannot grow
unbounded.

**A4 — Path traversal / ambiguous paths.** `/anthropic/../…` (raw or
percent-encoded) reached the upstream where normalization could change the
routed path. Impact was limited (the upstream host is fixed by the prefix
— this was never an open proxy or SSRF vector, since routing is a
hardcoded allowlist), but ambiguity is still rejected: any path containing
`..`, backslashes, NULs, or malformed percent-encoding now returns 400 in
all implementations, verified against encoded variants.

**A5 — Node request timeout would kill long streams.** Node's default
`server.requestTimeout` (300 s) would sever generations longer than five
minutes — a reliability bug that invites "just disable TLS timeouts"
workarounds. *Fixed:* request timeout disabled in favor of the explicit
600 s upstream timeout, with tight `headersTimeout` (30 s) retained
against slowloris, plus `maxHeadersCount`/`MaxHeaderBytes`/
`h11_max_incomplete_event_size` caps on header blocks.

**A6 — Information leaks.** Upstream error details (`err.code`, exception
names) were sent to clients, and full URLs including query strings were
logged — query strings can carry keys on some Google-style APIs. *Fixed:*
clients now get generic `upstream error` bodies (details go to server
logs), all error responses carry `Cache-Control: no-store`, and logs
record only method, query-stripped path, status, and device CN — never
headers or bodies.

**A7 — Header hygiene.** `Forwarded`/`X-Forwarded-*` from clients (or
added by edges) and the `Expect` header were forwarded upstream, leaking
topology and device addresses. *Fixed:* stripped in all implementations,
alongside the RFC 9110 hop-by-hop set; the Worker also strips `cf-*`.

**A8 — CA key stored in cleartext, long-lived device certs.** *Fixed:*
`ca.key` is now AES-256-encrypted at generation (passphrase prompted, or
`CA_KEY_PASS` env for automation — passed via `env:` so it never appears
in `ps`); device certs now live 365 days instead of 825. The CA key never
needs to be on the proxy host at all.

**A9 — systemd unit would crash Node.** `MemoryDenyWriteExecute=true` in
the Node unit blocks V8's JIT (W^X). *Fixed:* removed for Node (kept for
Go, which needs no writable-executable memory), and all three units gained
fuller sandboxing: `SystemCallFilter=@system-service`,
`RestrictNamespaces`, `LockPersonality`, `ProtectProc=invisible`,
`ProtectKernelModules`, `ProtectClock`, `ProtectHostname`,
`SystemCallArchitectures=native`.

**A10 — Container hardening gaps.** *Fixed:* compose services now add
`cap_drop: [ALL]`, `pids_limit: 100`, `mem_limit: 256m` on top of the
existing non-root user, `read_only: true` and `no-new-privileges`. Certs
remain runtime bind-mounts, never image layers.

**A11 — Device allowlisting.** CA-signed used to be sufficient; there was
no way to disable one device short of revocation. *Added:*
`ALLOWED_DEVICES` (comma-separated CNs) as an instant application-layer
kill switch in Node and Go, complementing (not replacing) the CRL.

## What was already sound (kept)

Fixed upstream allowlist (no open-proxy/SSRF surface — the Host header and
request contents cannot change the destination; `EXTRA_UPSTREAMS` extends
the allowlist only via deploy-time operator configuration, never from
client input); mTLS enforced at the
handshake so unauthenticated peers never speak HTTP; no credentials at
rest; hop-by-hop header stripping; EKU separation between server
(`serverAuth`) and client (`clientAuth`) certs so neither can impersonate
the other; non-root containers; keys held only in per-request memory.

## Limitations and residual risks

- **Python keys rate limits on client IP, not certificate CN** — uvicorn's
  ASGI interface does not expose the peer certificate. Behind NAT, devices
  sharing an IP share a bucket. Node/Go key on the CN; prefer them if
  per-device limits matter. `ALLOWED_DEVICES` is likewise Node/Go-only.
- **A device compromise is a full compromise of that device's access**: the
  attacker gets both the cert and the keys stored in the app. mTLS narrows
  who can talk to the proxy; it cannot make a stolen unlocked phone safe.
  Mitigations: hardware-backed keystores (non-exportable keys), short cert
  lifetimes, fast revocation (`revoke` + `TLS_CRL`), rate limits, and
  monitoring the `device=` field in logs for anomalies.
- **CRL is loaded at startup** — revocation takes effect on proxy restart
  (systemd/compose restart is one command; the units auto-restart).
- **The serverless variant trusts Cloudflare's edge** for mTLS and sees
  keys transit that edge, as with any TLS-terminating CDN.
- **The proxy can't inspect what it forwards** (by design — it never parses
  bodies). Provider-side spend limits on each API key are the backstop for
  abuse and should be set regardless.
- **In-memory rate limits are per-instance.** If you scale to multiple
  replicas, limits multiply accordingly; keep a single instance or put
  shared limiting in front.

## Operator checklist

Keep `ca.key` off the proxy host (offline, encrypted — it already is);
set provider-side spend caps on every API key; alert on repeated
`rejected TLS client` and 429 log lines; rotate device certs on schedule
(365-day expiry forces this); pin base-image digests and rebuild images
monthly for patched OpenSSL; when a device is lost, run
`generate-certs.sh revoke <device>` and restart the proxy (or drop the CN
from `ALLOWED_DEVICES` for an instant block, then revoke).
