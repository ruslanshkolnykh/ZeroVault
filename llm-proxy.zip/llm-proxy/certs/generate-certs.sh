#!/usr/bin/env bash
#
# generate-certs.sh — creates a private CA, a server certificate for the
# proxy, and one or more client certificates for AI/mobile agent devices.
#
# The proxy authenticates devices at the TLS layer (mTLS): it only trusts
# client certificates signed by ca.crt. No credential of any kind is
# stored on the proxy — the CA public cert is not a secret, and provider
# API keys live exclusively on the agent's device.
#
# Usage:
#   ./generate-certs.sh init <proxy-hostname-or-ip>   # CA + server cert
#   ./generate-certs.sh client <device-name>          # client cert + .p12 for mobile
#   ./generate-certs.sh revoke <device-name>          # revoke a client cert, rebuild CRL
#
set -euo pipefail
cd "$(dirname "$0")"

DAYS_CA=3650
DAYS_SERVER=825
DAYS_CLIENT=365   # short device-cert lifetime limits the damage of a lost phone
# CNSA-aligned defaults: NIST P-384 + SHA-384 (override: CURVE=prime256v1
# HASH=sha256 for constrained fleets that don't need NSS-grade crypto).
CURVE="${CURVE:-secp384r1}"
HASH="${HASH:-sha384}"

# The CA private key is stored encrypted (AES-256). openssl prompts for the
# passphrase when signing; set CA_KEY_PASS in the environment to automate
# (the env: form keeps the passphrase out of `ps` output, unlike pass:).
PASS_IN=(); PASS_OUT=()
if [[ -n "${CA_KEY_PASS:-}" ]]; then
  PASS_IN=(-passin env:CA_KEY_PASS)
  PASS_OUT=(-pass env:CA_KEY_PASS)
fi

init() {
  local host="${1:?usage: generate-certs.sh init <proxy-hostname-or-ip>}"

  # --- CA (private key encrypted with AES-256) ------------------------
  openssl genpkey -algorithm EC -pkeyopt "ec_paramgen_curve:$CURVE" \
    -aes-256-cbc ${PASS_OUT[@]+"${PASS_OUT[@]}"} -out ca.key
  openssl req -x509 -new -key ca.key ${PASS_IN[@]+"${PASS_IN[@]}"} -$HASH -days "$DAYS_CA" \
    -subj "/CN=llm-proxy-ca" \
    -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
    -addext "keyUsage=critical,keyCertSign,cRLSign" \
    -out ca.crt
  touch index.txt
  echo 1000 > serial
  echo 1000 > crlnumber

  # --- Server cert ----------------------------------------------------
  local san="DNS:${host}"
  [[ "$host" =~ ^[0-9.]+$ ]] && san="IP:${host}"

  openssl ecparam -name "$CURVE" -genkey -noout -out server.key
  openssl req -new -key server.key -subj "/CN=${host}" -out server.csr
  openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key ${PASS_IN[@]+"${PASS_IN[@]}"} -CAcreateserial \
    -days "$DAYS_SERVER" -"$HASH" \
    -extfile <(printf "subjectAltName=%s\nextendedKeyUsage=serverAuth\nkeyUsage=critical,digitalSignature,keyEncipherment" "$san") \
    -out server.crt
  rm server.csr
  chmod 600 ca.key server.key

  echo "CA + server certificate created for ${host}."
  echo "Deploy to proxy:  ca.crt  server.crt  server.key"
  echo "NEVER deploy:     ca.key  (encrypted, but keep it offline anyway; it mints device identities)"
}

client() {
  local name="${1:?usage: generate-certs.sh client <device-name>}"
  openssl ecparam -name "$CURVE" -genkey -noout -out "client-${name}.key"
  openssl req -new -key "client-${name}.key" -subj "/CN=${name}" -out "client-${name}.csr"
  openssl x509 -req -in "client-${name}.csr" -CA ca.crt -CAkey ca.key ${PASS_IN[@]+"${PASS_IN[@]}"} -CAcreateserial \
    -days "$DAYS_CLIENT" -"$HASH" \
    -extfile <(printf "extendedKeyUsage=clientAuth\nkeyUsage=critical,digitalSignature") \
    -out "client-${name}.crt"
  rm "client-${name}.csr"

  # PKCS#12 bundle for import into iOS / Android keystores.
  # You will be prompted for an export password — the mobile OS asks for
  # it once at import time.
  openssl pkcs12 -export \
    -inkey "client-${name}.key" -in "client-${name}.crt" \
    -certfile ca.crt -name "${name}" -out "client-${name}.p12"
  chmod 600 "client-${name}.key" "client-${name}.p12"

  echo "Client certificate for '${name}' created."
  echo "Install client-${name}.p12 on the device, then delete the .p12 from this machine."
}

revoke() {
  local name="${1:?usage: generate-certs.sh revoke <device-name>}"
  cat > openssl-crl.cnf <<'EOF'
[ca]
default_ca = revocation_ca
[revocation_ca]
database  = index.txt
crlnumber = crlnumber
default_md = sha384
default_crl_days = 30
EOF
  openssl ca -config openssl-crl.cnf -revoke "client-${name}.crt" -cert ca.crt -keyfile ca.key ${PASS_IN[@]+"${PASS_IN[@]}"}
  openssl ca -config openssl-crl.cnf -gencrl -cert ca.crt -keyfile ca.key ${PASS_IN[@]+"${PASS_IN[@]}"} -out crl.pem
  echo "Revoked '${name}'. Redeploy crl.pem to the proxy (TLS_CRL=/path/to/crl.pem)."
  echo "Node/Go reload the CRL automatically within ~60s; Python needs a restart."
}

case "${1:-}" in
  init)   shift; init "$@";;
  client) shift; client "$@";;
  revoke) shift; revoke "$@";;
  *) echo "usage: $0 {init <host>|client <name>|revoke <name>}" >&2; exit 1;;
esac
