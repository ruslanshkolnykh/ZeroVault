# Serverless deployment (Cloudflare Workers)

Serverless platforms terminate TLS at their edge, so the proxy code itself
cannot demand a client certificate the way the Node/Python/Go servers do.
On Cloudflare the edge does the mTLS for you; the Worker then routes.

## Setup

1. **Client certificates.** In the Cloudflare dashboard: *SSL/TLS → Client
   Certificates*. Either create certificates from Cloudflare's managed CA
   (simplest — download the generated cert/key per device), or use
   *Bring Your Own CA* (API only) to upload the `ca.crt` produced by
   `certs/generate-certs.sh`, so the same device certs work against both
   the serverless and self-hosted deployments.

2. **Enable mTLS on the hostname**, e.g. `llm-proxy.example.com`
   (*Client Certificates → Edit zone hostnames*).

3. **Enforce it with a WAF rule** — enabling mTLS alone does not block
   requests without a cert:

   ```
   (http.host eq "llm-proxy.example.com" and not cf.tls_client_auth.cert_verified)
   → Block
   ```

4. **Rate limiting.** The self-hosted variants rate-limit per device in
   code; here, add a Cloudflare *Rate limiting rule* on the hostname
   (e.g. 120 requests/minute per `cf.tls_client_auth.cert_fingerprint_sha256`
   or per IP, depending on your plan).

5. **Deploy the Worker:**

   ```bash
   cd deploy/serverless
   npx wrangler deploy
   ```

   Set the route in `wrangler.toml` to the mTLS-protected hostname. The
   Worker also re-checks `request.cf.tlsClientAuth.certVerified` itself as
   defense in depth.

## Caveats vs self-hosted

- CPU time per request is limited (fine for proxying; the clock mostly
  ticks while streaming, which is I/O and doesn't count against CPU).
- SSE streaming works; the Worker passes the upstream body through as a
  stream.
- Certificate revocation is managed in the Cloudflare dashboard instead
  of a CRL file.
- Your provider API keys transit Cloudflare's edge (as they would any
  TLS-terminating CDN). If that is unacceptable, use the self-hosted
  variants.

## Other platforms

AWS: API Gateway supports mTLS (upload `ca.crt` as the truststore to S3)
in front of a Lambda that does the same path-prefix routing. GCP: mTLS
requires an external HTTPS LB with a TrustConfig in Certificate Manager in
front of Cloud Run. Plain Vercel/Netlify functions do not support custom
client-certificate validation — avoid for this design.
