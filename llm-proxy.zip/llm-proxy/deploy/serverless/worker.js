/**
 * llm-proxy (Cloudflare Worker) — serverless variant.
 *
 * IMPORTANT — how mTLS works here: a Worker cannot terminate TLS itself,
 * so client-certificate auth is done by Cloudflare's edge ("mTLS rules" /
 * API Shield). Setup (see README-serverless.md):
 *   1. Upload ca.crt under SSL/TLS -> Client Certificates (Bring Your Own CA),
 *      or issue device certs from Cloudflare's managed CA.
 *   2. Enable mTLS for the proxy hostname.
 *   3. Add a WAF rule: block unless cf.tls_client_auth.cert_verified.
 * The Worker double-checks the edge's verdict below (defense in depth) and
 * then routes by path prefix. It stores no credentials: provider API keys
 * arrive from the AI/mobile agent in headers and are forwarded verbatim.
 *
 * Streaming: Workers pass Response bodies through as streams, so SSE works.
 */

// Prefix -> upstream base. The Worker forwards the remaining path verbatim;
// apps use each provider's documented path after the prefix.
const UPSTREAMS = {
  // major labs
  anthropic: 'https://api.anthropic.com',
  openai: 'https://api.openai.com',
  deepseek: 'https://api.deepseek.com',
  gemini: 'https://generativelanguage.googleapis.com',
  mistral: 'https://api.mistral.ai',
  cohere: 'https://api.cohere.com',
  ai21: 'https://api.ai21.com',
  perplexity: 'https://api.perplexity.ai',
  stability: 'https://api.stability.ai',
  // China-based
  dashscope: 'https://dashscope-intl.aliyuncs.com',
  moonshot: 'https://api.moonshot.ai',
  zhipu: 'https://open.bigmodel.cn',
  zai: 'https://api.z.ai',
  siliconflow: 'https://api.siliconflow.com',
  // Russia-based
  yandex: 'https://llm.api.cloud.yandex.net',
  gigachat: 'https://api.giga.chat',
  'gigachat-auth': 'https://ngw.devices.sberbank.ru:9443', // OAuth token endpoint
  // embeddings, image & specialized
  voyage: 'https://api.voyageai.com',
  jina: 'https://api.jina.ai',
  nomic: 'https://api-atlas.nomic.ai',
  recraft: 'https://external.api.recraft.ai',
  upstage: 'https://api.upstage.ai',
};

const HOP_BY_HOP = [
  'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
  'te', 'trailer', 'transfer-encoding', 'upgrade',
];

function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

export default {
  async fetch(request) {
    // Defense in depth: the WAF mTLS rule should already have blocked
    // unverified clients; refuse anyway if the edge says the cert is bad.
    const tls = request.cf?.tlsClientAuth;
    if (!tls || tls.certVerified !== 'SUCCESS') {
      return json(401, { error: 'client certificate required' });
    }

    const url = new URL(request.url);
    if (url.pathname === '/healthz') return json(200, { ok: true });

    // Path traversal guard (URL already normalizes, but belt and braces).
    if (url.pathname.includes('..') || url.pathname.includes('\\')) {
      return json(400, { error: 'invalid path' });
    }

    const match = url.pathname.match(/^\/([a-z0-9-]+)(\/.*)?$/);
    if (!match || !UPSTREAMS[match[1]]) {
      return json(404, { error: 'unknown route' });
    }

    const target = new URL(UPSTREAMS[match[1]]);
    target.pathname = match[2] || '/';
    target.search = url.search;

    const headers = new Headers(request.headers);
    for (const h of HOP_BY_HOP) headers.delete(h);
    headers.delete('host');
    // Don't leak Cloudflare/edge metadata upstream.
    for (const h of [...headers.keys()]) {
      if (h.startsWith('cf-') || h.startsWith('x-forwarded-')) headers.delete(h);
    }

    return fetch(target, {
      method: request.method,
      headers,
      body: request.body, // streamed
      redirect: 'manual',
    });
  },
};
