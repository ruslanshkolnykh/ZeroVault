# Build from repo root:  docker build -f deploy/docker/Dockerfile.go -t zerovaultproxy:go .
FROM golang:1.22-alpine AS build
WORKDIR /src
COPY go/ .
RUN CGO_ENABLED=0 go build -ldflags="-s -w" -o /llm-proxy .

FROM scratch
COPY --from=build /llm-proxy /llm-proxy
COPY --from=build /etc/ssl/certs/ca-certificates.crt /etc/ssl/certs/
ENV TLS_CERT=/certs/server.crt TLS_KEY=/certs/server.key TLS_CA=/certs/ca.crt PORT=8443
EXPOSE 8443
ENTRYPOINT ["/llm-proxy"]
