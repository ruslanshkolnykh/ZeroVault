#!/usr/bin/env bash
# install-go.sh — create the llm-proxy service (Go runtime) from scratch.
# Hardened: dedicated no-login system user, root-owned static binary,
# 640 keys, sandboxed systemd unit (incl. W^X), post-install mTLS check.
# The Go toolchain is only needed to BUILD; the binary has no runtime deps —
# build on this host (default) or copy a prebuilt binary in with BINARY=path.
#
# Usage (as root, from the repo root, after placing server.crt/server.key/ca.crt
# in certs/):   sudo deploy/install/install-go.sh
#          or:  sudo BINARY=/path/to/llm-proxy deploy/install/install-go.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

require_root
require_apt
require_systemd

# --- build (or take a prebuilt binary) -------------------------------------
if [[ -n "${BINARY:-}" ]]; then
  [[ -f "$BINARY" ]] || die "BINARY=$BINARY not found"
  BUILT="$BINARY"
else
  if ! command -v go >/dev/null; then
    log "installing Go toolchain (build-time only)"
    apt-get update -qq
    apt-get install -y -qq golang-go >/dev/null
  fi
  log "building static binary with $(go version | cut -d' ' -f3)"
  BUILT="$(mktemp -d)/zerovaultproxy"
  (cd "$REPO_ROOT/go" && CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o "$BUILT" .)
fi

# --- app files (root-owned, service can read/execute but never write) ------
create_user
create_layout
install -m 750 -o root -g "$SVC_USER" "$BUILT" "$APP_DIR/zerovaultproxy"
install_certs

# --- service ---------------------------------------------------------------
install_unit "$REPO_ROOT/deploy/systemd/zerovaultproxy-go.service"
start_and_verify
log "done — see runbooks/RUNBOOK-go.md for operations"
