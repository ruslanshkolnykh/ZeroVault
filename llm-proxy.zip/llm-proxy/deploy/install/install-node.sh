#!/usr/bin/env bash
# install-node.sh — create the llm-proxy service (Node.js runtime) from scratch.
# Hardened: dedicated no-login system user, root-owned code, 640 keys,
# sandboxed systemd unit, post-install mTLS enforcement check.
#
# Usage (as root, from the repo root, after placing server.crt/server.key/ca.crt
# in certs/):   sudo deploy/install/install-node.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

require_root
require_apt
require_systemd

# --- runtime ---------------------------------------------------------------
if ! command -v node >/dev/null || [[ "$(node -e 'console.log(process.versions.node.split(".")[0])')" -lt 18 ]]; then
  log "installing Node.js from distro repositories"
  apt-get update -qq
  apt-get install -y -qq nodejs >/dev/null
  [[ "$(node -e 'console.log(process.versions.node.split(".")[0])')" -ge 18 ]] \
    || die "distro Node.js is older than 18 — install Node 18+ (e.g. NodeSource) and re-run"
fi
log "node $(node --version)"

# --- app files (root-owned, service can read but never write) --------------
create_user
create_layout
install -d -m 750 -o root -g "$SVC_USER" "$APP_DIR/node"
install -m 640 -o root -g "$SVC_USER" "$REPO_ROOT/node/server.js" "$REPO_ROOT/node/package.json" "$APP_DIR/node/"
install_certs

# --- service ---------------------------------------------------------------
install_unit "$REPO_ROOT/deploy/systemd/zerovaultproxy-node.service"
start_and_verify
log "done — see runbooks/RUNBOOK-node.md for operations"
