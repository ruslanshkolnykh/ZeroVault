#!/usr/bin/env bash
# common.sh — shared, hardened bootstrap steps for the llm-proxy installers.
# Sourced by install-node.sh / install-python.sh / install-go.sh.
# Debian/Ubuntu (apt). Run as root from the repo root.

set -euo pipefail
umask 027

APP_DIR="${APP_DIR:-/opt/zerovaultproxy}"
SVC_USER="${SVC_USER:-zerovaultproxy}"
SVC_NAME="${SVC_NAME:-zerovaultproxy}"
PORT="${PORT:-8443}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

log()  { printf '\033[1;32m[install]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[fail]\033[0m %s\n' "$*" >&2; exit 1; }

require_root() { [[ $EUID -eq 0 ]] || die "run as root (sudo $0)"; }

require_apt() {
  command -v apt-get >/dev/null || die "this installer targets Debian/Ubuntu (apt). See the runbook for manual steps on other distros."
}

require_systemd() {
  command -v systemctl >/dev/null || die "systemd not found — use the Docker deployment instead (deploy/docker)."
}

create_user() {
  if ! id -u "$SVC_USER" >/dev/null 2>&1; then
    log "creating system user $SVC_USER"
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SVC_USER"
  fi
}

# Layout:
#   /opt/zerovaultproxy/           root:zerovaultproxy 750
#   /opt/zerovaultproxy/certs/     root:zerovaultproxy 750  (server.crt/key, ca.crt, crl.pem)
# Code is owned by root and only readable by the service user — the service
# can never modify its own binary/source (tamper resistance).
create_layout() {
  install -d -m 750 -o root -g "$SVC_USER" "$APP_DIR" "$APP_DIR/certs"
}

install_certs() {
  local src="$REPO_ROOT/certs"
  for f in server.crt server.key ca.crt; do
    [[ -f "$src/$f" ]] || die "missing $src/$f — run: cd certs && ./generate-certs.sh init <hostname> (on your CA machine), then copy server.crt server.key ca.crt here. NEVER copy ca.key to this host."
  done
  [[ -f "$src/ca.key" ]] && warn "certs/ca.key found on this host — the CA key does NOT belong on the proxy. Move it offline after install."
  install -m 640 -o root -g "$SVC_USER" "$src/server.crt" "$src/ca.crt" "$APP_DIR/certs/"
  install -m 640 -o root -g "$SVC_USER" "$src/server.key" "$APP_DIR/certs/"
  [[ -f "$src/crl.pem" ]] && install -m 640 -o root -g "$SVC_USER" "$src/crl.pem" "$APP_DIR/certs/"
  log "certificates installed to $APP_DIR/certs (server.key mode 640 root:$SVC_USER)"
}

install_unit() {
  local unit_src="$1"
  install -m 644 -o root -g root "$unit_src" "/etc/systemd/system/${SVC_NAME}.service"
  systemctl daemon-reload
  systemctl enable "$SVC_NAME" >/dev/null
}

start_and_verify() {
  systemctl restart "$SVC_NAME"
  log "waiting for :$PORT ..."
  for _ in $(seq 1 20); do
    sleep 0.5
    if (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null; then exec 3>&- 3<&-; break; fi
  done
  systemctl is-active --quiet "$SVC_NAME" || { journalctl -u "$SVC_NAME" -n 20 --no-pager >&2; die "service failed to start"; }

  # Verify mTLS is actually enforced: a handshake WITHOUT a client cert must fail.
  if command -v openssl >/dev/null; then
    if echo | openssl s_client -connect "127.0.0.1:$PORT" -CAfile "$APP_DIR/certs/ca.crt" 2>/dev/null \
        | grep -q "Verify return code: 0"; then
      # handshake itself may complete under TLS1.3 until first read; probe with HTTP
      :
    fi
    if curl -s --max-time 5 --cacert "$APP_DIR/certs/ca.crt" "https://127.0.0.1:$PORT/healthz" >/dev/null 2>&1; then
      die "SECURITY CHECK FAILED: /healthz answered WITHOUT a client certificate — mTLS is not enforced. Investigate before use."
    fi
    log "mTLS check passed: connection without a client certificate is refused"
  fi
  log "service $SVC_NAME is active. Verify with a device cert:"
  log "  curl --cacert ca.crt --cert client-<dev>.crt --key client-<dev>.key https://<host>:$PORT/healthz"
  warn "if a firewall is in use, allow the port, e.g.: ufw allow $PORT/tcp"
}
