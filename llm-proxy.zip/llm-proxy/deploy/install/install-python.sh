#!/usr/bin/env bash
# install-python.sh — create the llm-proxy service (Python runtime) from scratch.
# Hardened: dedicated no-login system user, root-owned code and venv,
# 640 keys, sandboxed systemd unit, post-install mTLS enforcement check.
#
# Usage (as root, from the repo root, after placing server.crt/server.key/ca.crt
# in certs/):   sudo deploy/install/install-python.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

require_root
require_apt
require_systemd

# --- runtime ---------------------------------------------------------------
log "installing Python runtime packages"
apt-get update -qq
apt-get install -y -qq python3 python3-venv >/dev/null
log "$(python3 --version)"

# --- app files (root-owned, service can read but never write) --------------
create_user
create_layout
install -d -m 750 -o root -g "$SVC_USER" "$APP_DIR/python"
install -m 640 -o root -g "$SVC_USER" "$REPO_ROOT/python/main.py" "$REPO_ROOT/python/requirements.txt" "$APP_DIR/python/"
install -m 750 -o root -g "$SVC_USER" "$REPO_ROOT/python/run.py" "$APP_DIR/python/"

# venv owned by root: the service cannot alter its own dependencies.
if [[ ! -x "$APP_DIR/python/.venv/bin/python" ]]; then
  log "creating virtualenv"
  python3 -m venv "$APP_DIR/python/.venv"
fi
log "installing pinned dependencies"
"$APP_DIR/python/.venv/bin/pip" install --quiet --upgrade pip
"$APP_DIR/python/.venv/bin/pip" install --quiet -r "$APP_DIR/python/requirements.txt"
chown -R "root:$SVC_USER" "$APP_DIR/python/.venv"
chmod -R o-rwx "$APP_DIR/python/.venv"
install_certs

# --- service ---------------------------------------------------------------
install_unit "$REPO_ROOT/deploy/systemd/zerovaultproxy-python.service"
start_and_verify
log "done — see runbooks/RUNBOOK-python.md for operations"
