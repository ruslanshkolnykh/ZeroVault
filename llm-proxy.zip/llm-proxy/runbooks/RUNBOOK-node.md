# Runbook — llm-proxy on Node.js

Operational guide for the Node.js runtime of llm-proxy: the stateless mTLS
gateway for 21 AI providers. Applies to a systemd deployment at
`/opt/zerovaultproxy` created by `deploy/install/install-node.sh`.

## 1. Service overview

| | |
|---|---|
| Service unit | `zerovaultproxy` (`/etc/systemd/system/zerovaultproxy.service`) |
| Process | `/usr/bin/node /opt/zerovaultproxy/node/server.js` |
| Runs as | `zerovaultproxy` (no-login system user; code is root-owned, read-only to it) |
| Listens | `:8443` (mTLS required — no valid client cert, no HTTP) |
| State | none — safe to kill, restart, or reinstall at any time |
| Requires | Node.js ≥ 18 (uses only the standard library) |

## 2. Fresh install (from scratch)

On your **CA machine** (not the proxy host):

```bash
cd certs
./generate-certs.sh init proxy.example.com     # CA + server cert (CA key stays here)
./generate-certs.sh client phone-001           # one per device -> .p12 bundle
```

Copy `server.crt`, `server.key`, `ca.crt` (never `ca.key`) into `certs/` on
the proxy host, then:

```bash
sudo deploy/install/install-node.sh
```

The installer creates the `zerovaultproxy` user, installs Node if missing, lays
out `/opt/zerovaultproxy` (root-owned code, keys mode 640), installs the
sandboxed systemd unit, starts the service, and **fails loudly if a request
without a client certificate is accepted** (mTLS self-check).

Verify from a machine holding a device cert:

```bash
curl --cacert ca.crt --cert client-phone-001.crt --key client-phone-001.key \
     https://proxy.example.com:8443/healthz          # -> {"ok":true}
```

## 3. Configuration

Set in the `[Service]` section of the unit (then `systemctl daemon-reload
&& systemctl restart zerovaultproxy`):

| Env var | Default | Purpose |
|---|---|---|
| `PORT` | 8443 | listen port |
| `TLS_CERT` / `TLS_KEY` / `TLS_CA` | `/opt/zerovaultproxy/certs/...` | server keypair, client CA |
| `TLS_CRL` | unset | CRL file — set after first revocation |
| `TLS_MIN_VERSION` | TLSv1.3 | `TLSv1.2` enables AEAD-only fallback for old devices |
| `ALLOWED_DEVICES` | unset (any CA-signed cert) | comma-separated cert CNs — instant allowlist |
| `RATE_LIMIT_RPM` / `RATE_LIMIT_BURST` | 120 / 30 | per-device token bucket (0 disables) |
| `MAX_BODY_BYTES` | 26214400 | request body cap |
| `EXTRA_UPSTREAMS` | unset | `alias=host,...` extra provider routes |
| `FIPS_MODE` | unset | `1` = TLS 1.3 only, FIPS-approved suites (see docs/COMPLIANCE.md) |
| `LOG_FORMAT` | text | `json` = structured audit records for SIEM ingestion |
| `LOG_LEVEL` | full | `minimal` = security events only, no per-request records |
| `LOG_DEVICE_HASH` | unset | salt — log a salted hash of the device CN instead of the CN |
| `MAX_CONNS` | 500 | concurrent TLS connection cap |
| `CRL_RELOAD_SECS` | 60 | how often the CRL file is re-checked (no restart needed) |

## 4. Routine operations

```bash
systemctl status zerovaultproxy            # state
journalctl -u zerovaultproxy -f            # live logs (method/path/status/device only)
systemctl restart zerovaultproxy           # safe anytime; in-flight requests drop
```

**Enroll a device:** use the CA Console (`tools/ca-console`, runs on the CA machine) — or on the CA machine `./generate-certs.sh client <name>`,
deliver the `.p12` to the device over a trusted channel, delete the local
copy. No proxy change needed.

**Revoke a device (lost/stolen phone):**

```bash
# CA machine:
./generate-certs.sh revoke phone-001            # updates crl.pem
scp crl.pem proxy:/opt/zerovaultproxy/certs/         # then on the proxy:
sudo chown root:zerovaultproxy /opt/zerovaultproxy/certs/crl.pem && sudo chmod 640 $_
# ensure the unit has Environment=TLS_CRL=/opt/zerovaultproxy/certs/crl.pem
sudo systemctl restart zerovaultproxy   # optional — the CRL hot-reloads within ~60s
```

For an instant block without touching the CA, add every *other* device to
`ALLOWED_DEVICES` (drops the stolen CN) and restart — then revoke properly.

**Rotate the server certificate** (expires ~27 months): on the CA machine
`./generate-certs.sh init <host>` regenerates it against the same CA; copy
`server.crt`/`server.key` over and restart. Device certs are unaffected.

**Update the proxy code:**

```bash
sudo install -m 640 -o root -g zerovaultproxy node/server.js /opt/zerovaultproxy/node/server.js
sudo systemctl restart zerovaultproxy
# rollback = reinstall the previous server.js (keep a copy) and restart
```

**Upgrade Node.js:** `apt-get upgrade nodejs` (or your Node source), then
restart the unit. Anything ≥ 18 works.

## 5. Monitoring

Log lines worth alerting on:

- `rejected TLS client` — repeated bursts = revoked/foreign device or scanner.
- `-> 429` — a device is hitting its rate limit (stolen cert or runaway agent).
- `denied device=... (not in ALLOWED_DEVICES)` — blocked device still trying.
- `upstream error` / `-> 502` — provider outage or egress problem.

Health probe (needs a monitoring client cert — enroll one like a device):
`curl --cacert ... --cert ... --key ... https://host:8443/healthz`.

## 6. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Service exits at startup, `EACCES`/`ENOENT` in journal | cert files missing or unreadable by `zerovaultproxy` | check `/opt/zerovaultproxy/certs` perms (dir 750, files 640, group `zerovaultproxy`) |
| Devices get TLS handshake failure | cert not signed by this CA, expired (365 d), revoked, or device stuck on TLS 1.2 | `openssl x509 -in client.crt -noout -dates -issuer`; set `TLS_MIN_VERSION=TLSv1.2` only if the fleet needs it |
| Curl without cert *succeeds* | mTLS misconfigured — **treat as an incident** | check unit env `TLS_CA`; reinstall via `install-node.sh` (it re-runs the enforcement check) |
| Streams cut off mid-generation | a middlebox/timeout in front of the proxy | the proxy allows 10-min streams; check LB/NAT idle timeouts |
| 404 `unknown route` | wrong prefix | prefixes are the README routing table (e.g. `/gemini/v1beta/...`) |
| 413 | body over `MAX_BODY_BYTES` | raise it in the unit if legitimate |
| Node crashes on start under systemd | `MemoryDenyWriteExecute` added to the unit | remove it — V8's JIT needs W^X (documented in SECURITY.md A9) |

## 7. Disaster recovery

- **Proxy host lost:** nothing secret was on it. Rebuild any host, copy the
  three cert files, re-run `install-node.sh`. Devices reconnect unchanged.
- **Server key leaked:** rotate the server cert (above). Past traffic stays
  safe (forward secrecy); devices unaffected.
- **CA key compromised:** the only expensive event. Generate a new CA
  (`init`), reissue every device cert, replace `ca.crt` on the proxy.
  `ALLOWED_DEVICES` can bridge the gap while re-enrolling.
