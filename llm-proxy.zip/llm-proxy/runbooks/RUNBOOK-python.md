# Runbook — llm-proxy on Python

Operational guide for the Python (FastAPI/uvicorn) runtime of llm-proxy:
the stateless mTLS gateway for 21 AI providers. Applies to a systemd
deployment at `/opt/zerovaultproxy` created by `deploy/install/install-python.sh`.

## 1. Service overview

| | |
|---|---|
| Service unit | `zerovaultproxy` (`/etc/systemd/system/zerovaultproxy.service`) |
| Process | `/opt/zerovaultproxy/python/.venv/bin/python /opt/zerovaultproxy/python/run.py` |
| Runs as | `zerovaultproxy` (no-login system user; code and venv root-owned, read-only to it) |
| Listens | `:8443` (mTLS enforced by `run.py`'s SSL context, incl. CRL) |
| State | none — safe to kill, restart, or reinstall at any time |
| Requires | Python 3.10+, deps pinned in `requirements.txt` inside a root-owned venv |

**Runtime-specific caveats** (differences from Node/Go — see SECURITY.md):
rate limiting keys on **client IP**, not certificate CN (uvicorn does not
expose the peer cert to the app), and `ALLOWED_DEVICES` is not available.
Revocation via CRL works fully. If per-device limits/allowlisting matter,
prefer the Node or Go runtime.

## 2. Fresh install (from scratch)

On your **CA machine** (not the proxy host):

```bash
cd certs
./generate-certs.sh init proxy.example.com     # CA + server cert (CA key stays here)
./generate-certs.sh client phone-001           # one per device -> .p12 bundle
```

Copy `server.crt`, `server.key`, `ca.crt` (never `ca.key`) into `certs/` on
the proxy host, then:

```bash
sudo deploy/install/install-python.sh
```

The installer creates the `zerovaultproxy` user, installs `python3-venv`, builds
a root-owned virtualenv with pinned dependencies, lays out `/opt/zerovaultproxy`
(keys mode 640), installs the sandboxed systemd unit, starts the service,
and **fails loudly if a request without a client certificate is accepted**
(mTLS self-check).

Verify from a machine holding a device cert:

```bash
curl --cacert ca.crt --cert client-phone-001.crt --key client-phone-001.key \
     https://proxy.example.com:8443/healthz          # -> {"ok":true}
```

## 3. Configuration

Set in the `[Service]` section of the unit (then `systemctl daemon-reload
&& systemctl restart zerovaultproxy`):

| Env var | Default | Purpose |
|---|---|---|
| `PORT` | 8443 | listen port |
| `CERTS_DIR` | `/opt/zerovaultproxy/certs` | directory with server.crt/key + ca.crt |
| `TLS_CRL` | unset | CRL file — set after first revocation |
| `TLS_MIN_VERSION` | TLSv1.3 | `TLSv1.2` enables AEAD-only fallback for old devices |
| `RATE_LIMIT_RPM` / `RATE_LIMIT_BURST` | 120 / 30 | per-client-IP token bucket (0 disables) |
| `MAX_BODY_BYTES` | 26214400 | request body cap |
| `EXTRA_UPSTREAMS` | unset | `alias=host,...` extra provider routes |
| `LOG_FORMAT` / `LOG_LEVEL` | text / full | `json` structured records; `minimal` = errors and security events only |

## 4. Routine operations

```bash
systemctl status zerovaultproxy            # state
journalctl -u zerovaultproxy -f            # live logs (method/path/status only)
systemctl restart zerovaultproxy           # safe anytime; in-flight requests drop
```

**Enroll a device:** use the CA Console (`tools/ca-console`, runs on the CA machine) — or on the CA machine `./generate-certs.sh client <name>`,
deliver the `.p12` to the device over a trusted channel, delete the local
copy. No proxy change needed.

**Revoke a device (lost/stolen phone):**

```bash
# CA machine:
./generate-certs.sh revoke phone-001            # updates crl.pem
scp crl.pem proxy:/opt/zerovaultproxy/certs/         # then on the proxy:
sudo chown root:zerovaultproxy /opt/zerovaultproxy/certs/crl.pem && sudo chmod 640 $_
# ensure the unit has Environment=TLS_CRL=/opt/zerovaultproxy/certs/crl.pem
sudo systemctl restart zerovaultproxy
```

**Rotate the server certificate** (expires ~27 months): regenerate on the
CA machine (`init`), copy `server.crt`/`server.key` over, restart. Device
certs are unaffected.

**Update the proxy code:**

```bash
sudo install -m 640 -o root -g zerovaultproxy python/main.py /opt/zerovaultproxy/python/main.py
sudo install -m 750 -o root -g zerovaultproxy python/run.py  /opt/zerovaultproxy/python/run.py
sudo systemctl restart zerovaultproxy
```

**Update dependencies** (security patches for fastapi/httpx/uvicorn):

```bash
sudo /opt/zerovaultproxy/python/.venv/bin/pip install --upgrade -r /opt/zerovaultproxy/python/requirements.txt
sudo systemctl restart zerovaultproxy
# rollback: pip install 'httpx==<previous>' etc., restart
```

## 5. Monitoring

Log lines worth alerting on: repeated TLS handshake errors (revoked or
foreign devices, scanners), `429` responses (an IP hitting its bucket),
`502 upstream error` (provider outage or egress problem). Health probe
requires a monitoring client cert — enroll one like a device.

## 6. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Unit exits at startup, `PermissionError` on certs | files unreadable by `zerovaultproxy` | dir 750, files 640, group `zerovaultproxy` |
| `ModuleNotFoundError` | venv missing/broken | re-run `install-python.sh` (idempotent) |
| Devices get TLS handshake failure | cert not from this CA, expired (365 d), revoked, or device stuck on TLS 1.2 | inspect with `openssl x509 -noout -dates -issuer`; consider `TLS_MIN_VERSION=TLSv1.2` |
| Curl without cert *succeeds* | mTLS misconfigured — **incident** | check `run.py` is the entrypoint (it sets CERT_REQUIRED); re-run installer |
| Two devices behind one NAT hit limits early | IP-keyed rate limiting | raise `RATE_LIMIT_RPM` or use Node/Go runtime |
| Streams cut off | middlebox timeout in front | proxy allows 10-min streams; check LB/NAT idle timeouts |
| 404 `unknown route` | wrong prefix | see README routing table |

## 7. Disaster recovery

Identical to the other runtimes: the host holds no secrets, so rebuild +
copy 3 cert files + `install-python.sh` restores service. Server-key leak →
rotate server cert (forward secrecy protects recorded traffic). CA-key
compromise → new CA, reissue all device certs, replace `ca.crt`.
