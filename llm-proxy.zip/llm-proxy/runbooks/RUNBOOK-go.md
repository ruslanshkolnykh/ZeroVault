# Runbook — llm-proxy on Go

Operational guide for the Go runtime of llm-proxy: the stateless mTLS
gateway for 21 AI providers. Applies to a systemd deployment at
`/opt/zerovaultproxy` created by `deploy/install/install-go.sh`.

## 1. Service overview

| | |
|---|---|
| Service unit | `zerovaultproxy` (`/etc/systemd/system/zerovaultproxy.service`) |
| Process | `/opt/zerovaultproxy/zerovaultproxy` (single static binary, CGO disabled) |
| Runs as | `zerovaultproxy` (no-login system user; binary root-owned, read/exec-only to it) |
| Listens | `:8443` (mTLS required; CRL checked in `VerifyPeerCertificate`) |
| State | none — safe to kill, restart, or reinstall at any time |
| Requires | nothing at runtime; Go toolchain only to build |

The Go runtime has the smallest attack surface of the three (stdlib only,
static binary, `MemoryDenyWriteExecute` enabled in its unit) — prefer it
when you have no reason to choose otherwise.

## 2. Fresh install (from scratch)

On your **CA machine** (not the proxy host):

```bash
cd certs
./generate-certs.sh init proxy.example.com     # CA + server cert (CA key stays here)
./generate-certs.sh client phone-001           # one per device -> .p12 bundle
```

Copy `server.crt`, `server.key`, `ca.crt` (never `ca.key`) into `certs/` on
the proxy host, then either build on the host:

```bash
sudo deploy/install/install-go.sh
```

or build elsewhere and ship only the binary (keeps compilers off the prod
host):

```bash
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -trimpath -ldflags="-s -w" -o llm-proxy ./go
sudo BINARY=./llm-proxy deploy/install/install-go.sh
```

The installer creates the `zerovaultproxy` user, installs the binary (mode 750,
root-owned), lays out certs (keys mode 640), installs the sandboxed systemd
unit (syscall filter + W^X), starts the service, and **fails loudly if a
request without a client certificate is accepted** (mTLS self-check).

Verify from a machine holding a device cert:

```bash
curl --cacert ca.crt --cert client-phone-001.crt --key client-phone-001.key \
     https://proxy.example.com:8443/healthz          # -> {"ok":true}
```

## 3. Configuration

Set in the `[Service]` section of the unit (then `systemctl daemon-reload
&& systemctl restart zerovaultproxy`):

| Env var | Default | Purpose |
|---|---|---|
| `PORT` | 8443 | listen port |
| `TLS_CERT` / `TLS_KEY` / `TLS_CA` | `/opt/zerovaultproxy/certs/...` | server keypair, client CA |
| `TLS_CRL` | unset | CRL file — enforced at every handshake once set |
| `TLS_MIN_VERSION` | 1.3 | `1.2` enables AEAD-only fallback for old devices |
| `ALLOWED_DEVICES` | unset (any CA-signed cert) | comma-separated cert CNs — instant allowlist |
| `RATE_LIMIT_RPM` / `RATE_LIMIT_BURST` | 120 / 30 | per-device token bucket (0 disables) |
| `MAX_BODY_BYTES` | 26214400 | request body cap |
| `EXTRA_UPSTREAMS` | unset | `alias=host,...` extra provider routes |
| `FIPS_MODE` | unset | `1` = TLS 1.3 only, FIPS-approved suites (see docs/COMPLIANCE.md) |
| `LOG_FORMAT` | text | `json` = structured audit records for SIEM ingestion |
| `LOG_LEVEL` | full | `minimal` = security events only, no per-request records |
| `LOG_DEVICE_HASH` | unset | salt — log a salted hash of the device CN instead of the CN |
| `MAX_CONNS` | 500 | concurrent TLS connection cap |
| `CRL_RELOAD_SECS` | 60 | how often the CRL file is re-checked (no restart needed) |

## 4. Routine operations

```bash
systemctl status zerovaultproxy            # state
journalctl -u zerovaultproxy -f            # live logs (method/path/device only)
systemctl restart zerovaultproxy           # safe anytime; in-flight requests drop
```

**Enroll a device:** use the CA Console (`tools/ca-console`, runs on the CA machine) — or on the CA machine `./generate-certs.sh client <name>`,
deliver the `.p12` to the device over a trusted channel, delete the local
copy. No proxy change needed.

**Revoke a device (lost/stolen phone):**

```bash
# CA machine:
./generate-certs.sh revoke phone-001            # updates crl.pem
scp crl.pem proxy:/opt/zerovaultproxy/certs/         # then on the proxy:
sudo chown root:zerovaultproxy /opt/zerovaultproxy/certs/crl.pem && sudo chmod 640 $_
# ensure the unit has Environment=TLS_CRL=/opt/zerovaultproxy/certs/crl.pem
sudo systemctl restart zerovaultproxy   # optional — the CRL hot-reloads within ~60s
```

For an instant block without touching the CA, list every *other* device in
`ALLOWED_DEVICES` and restart — then revoke properly.

**Rotate the server certificate** (expires ~27 months): regenerate on the
CA machine (`init`), copy `server.crt`/`server.key` over, restart. Device
certs are unaffected.

**Update the proxy:** build the new binary (either method above), then:

```bash
sudo install -m 750 -o root -g zerovaultproxy ./llm-proxy /opt/zerovaultproxy/zerovaultproxy
sudo systemctl restart zerovaultproxy
# rollback = keep the previous binary as /opt/zerovaultproxy/zerovaultproxy.prev and swap back
```

## 5. Monitoring

Log lines worth alerting on:

- `TLS handshake error ... client didn't provide a certificate` — scanners
  or misconfigured devices; bursts deserve a look.
- `client certificate revoked` — a revoked device is still trying.
- `denied device=...` — a CN outside `ALLOWED_DEVICES` is knocking.
- `429` / `upstream error` — stolen-cert abuse or provider outage.

Health probe requires a monitoring client cert — enroll one like a device.

## 6. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Unit exits at startup, `read CA:`/`load CRL:` in journal | cert/CRL files missing or unreadable | dir 750, files 640, group `zerovaultproxy` |
| Devices get TLS handshake failure | cert not from this CA, expired (365 d), revoked, or device stuck on TLS 1.2 | `openssl x509 -noout -dates -issuer`; consider `TLS_MIN_VERSION=1.2` |
| Curl without cert *succeeds* | mTLS misconfigured — **incident** | check unit env; re-run `install-go.sh` (re-runs the enforcement check) |
| `exec format error` | binary built for wrong arch | rebuild with matching `GOARCH` (e.g. `arm64`) |
| Streams cut off mid-generation | middlebox timeout in front of the proxy | proxy allows 10-min streams; check LB/NAT idle timeouts |
| 404 `unknown route` | wrong prefix | see README routing table |
| 413 | body over `MAX_BODY_BYTES` | raise it in the unit if legitimate |

## 7. Disaster recovery

- **Proxy host lost:** nothing secret was on it. Rebuild, copy the three
  cert files, re-run the installer (or drop in the prebuilt binary).
- **Server key leaked:** rotate the server cert. Recorded traffic stays
  safe (forward secrecy); devices unaffected.
- **CA key compromised:** new CA, reissue every device cert, replace
  `ca.crt` on the proxy; bridge with `ALLOWED_DEVICES` during re-enrollment.
