// llm-proxy (Go) — stateless mTLS reverse proxy for LLM APIs.
// Hardened build. See SECURITY.md for the threat model.
//
//   - mTLS at the handshake (RequireAndVerifyClientCert) plus optional CRL
//     checking and per-device CN allowlist.
//   - TLS 1.3 by default (TLS_MIN_VERSION=1.2 enables an AEAD/ECDHE-only
//     TLS 1.2 fallback for older Android devices).
//   - Stores NO credentials; provider keys pass through in memory only and
//     are never logged.
//   - Per-device token-bucket rate limiting and request body caps to
//     contain abuse from a stolen device certificate.
//
// Env vars: PORT (8443), TLS_CERT, TLS_KEY, TLS_CA, TLS_CRL, TLS_MIN_VERSION
// (1.3 default | 1.2), ALLOWED_DEVICES (comma-separated CNs), RATE_LIMIT_RPM
// (120; 0 disables), RATE_LIMIT_BURST (30), MAX_BODY_BYTES (25 MB).
package main

import (
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Prefix -> upstream base. The proxy forwards the remainder of the path
// verbatim, so the app uses each provider's documented path after the
// prefix (e.g. /zhipu/api/paas/v4/chat/completions). Auth headers pass
// through untouched (Bearer, x-goog-api-key, ...).
var upstreams = map[string]string{
	// major labs
	"anthropic":  "https://api.anthropic.com",
	"openai":     "https://api.openai.com",
	"deepseek":   "https://api.deepseek.com",
	"gemini":     "https://generativelanguage.googleapis.com",
	"mistral":    "https://api.mistral.ai",
	"cohere":     "https://api.cohere.com",
	"ai21":       "https://api.ai21.com",
	"perplexity": "https://api.perplexity.ai",
	"stability":  "https://api.stability.ai",
	// China-based
	"dashscope":   "https://dashscope-intl.aliyuncs.com",
	"moonshot":    "https://api.moonshot.ai",
	"zhipu":       "https://open.bigmodel.cn",
	"zai":         "https://api.z.ai",
	"siliconflow": "https://api.siliconflow.com",
	// Russia-based
	"yandex":        "https://llm.api.cloud.yandex.net",
	"gigachat":      "https://api.giga.chat",
	"gigachat-auth": "https://ngw.devices.sberbank.ru:9443", // OAuth token endpoint
	// embeddings, image & specialized
	"voyage":  "https://api.voyageai.com",
	"jina":    "https://api.jina.ai",
	"nomic":   "https://api-atlas.nomic.ai",
	"recraft": "https://external.api.recraft.ai",
	"upstage": "https://api.upstage.ai",
}

var (
	aliasRe = regexp.MustCompile(`^[a-z0-9-]+$`)
	hostRe  = regexp.MustCompile(`^[A-Za-z0-9.-]+(:\d+)?$`)
)

// loadExtraUpstreams merges operator-configured routes, e.g. a
// workspace-scoped DashScope host:
// EXTRA_UPSTREAMS="myalias=host.example.com,other=host2.example"
// Deploy-time only — clients can never add routes.
func loadExtraUpstreams() {
	for _, pair := range strings.Split(os.Getenv("EXTRA_UPSTREAMS"), ",") {
		alias, host, ok := strings.Cut(pair, "=")
		if !ok {
			continue
		}
		alias, host = strings.TrimSpace(alias), strings.TrimSpace(host)
		if !aliasRe.MatchString(alias) || !hostRe.MatchString(host) {
			log.Printf("ignoring invalid EXTRA_UPSTREAMS entry: %q", pair)
			continue
		}
		upstreams[alias] = "https://" + host
	}
}

func env(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func envInt(key string, fallback int64) int64 {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.ParseInt(v, 10, 64); err == nil {
			return n
		}
	}
	return fallback
}

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}

// ---- per-device token bucket -------------------------------------------

type bucket struct {
	tokens float64
	last   time.Time
}

type limiter struct {
	mu      sync.Mutex
	buckets map[string]*bucket
	rpm     float64
	burst   float64
}

func newLimiter(rpm, burst int64) *limiter {
	l := &limiter{buckets: map[string]*bucket{}, rpm: float64(rpm), burst: float64(burst)}
	go func() { // drop idle buckets so the map cannot grow unbounded
		for range time.Tick(time.Minute) {
			l.mu.Lock()
			for k, b := range l.buckets {
				if time.Since(b.last) > 10*time.Minute {
					delete(l.buckets, k)
				}
			}
			l.mu.Unlock()
		}
	}()
	return l
}

func (l *limiter) allow(device string) bool {
	if l.rpm <= 0 {
		return true
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	now := time.Now()
	b, ok := l.buckets[device]
	if !ok {
		b = &bucket{tokens: l.burst, last: now}
		l.buckets[device] = b
	}
	b.tokens = min(l.burst, b.tokens+now.Sub(b.last).Minutes()*l.rpm)
	b.last = now
	if b.tokens < 1 {
		return false
	}
	b.tokens--
	return true
}

// ---- structured audit logging (NIST AU-3: who, what, when, outcome) ------
// Never logged in ANY mode: headers, bodies, query strings, API keys.
// LOG_LEVEL=minimal logs security events only (no per-request records);
// LOG_DEVICE_HASH=<salt> pseudonymizes device CNs in every record.

var (
	jsonLogs       = os.Getenv("LOG_FORMAT") == "json"
	logMinimal     = os.Getenv("LOG_LEVEL") == "minimal"
	deviceHashSalt = os.Getenv("LOG_DEVICE_HASH")
)

func deviceLabel(cn string) string {
	if deviceHashSalt == "" {
		return cn
	}
	sum := sha256.Sum256([]byte(deviceHashSalt + cn))
	return hex.EncodeToString(sum[:])[:12]
}

func audit(evt string, fields map[string]any) {
	if jsonLogs {
		rec := map[string]any{"ts": time.Now().UTC().Format(time.RFC3339Nano), "evt": evt}
		for k, v := range fields {
			rec[k] = v
		}
		b, _ := json.Marshal(rec)
		log.SetFlags(0)
		log.Println(string(b))
		return
	}
	parts := make([]string, 0, len(fields))
	for k, v := range fields {
		parts = append(parts, fmt.Sprintf("%s=%v", k, v))
	}
	log.Printf("%s %s", evt, strings.Join(parts, " "))
}

// ---- connection cap (DoS containment, NIST SC-5) -------------------------

type limitListener struct {
	net.Listener
	sem chan struct{}
}

type limitConn struct {
	net.Conn
	release func()
}

func (c *limitConn) Close() error { c.release(); return c.Conn.Close() }

func (l *limitListener) Accept() (net.Conn, error) {
	l.sem <- struct{}{}
	conn, err := l.Listener.Accept()
	if err != nil {
		<-l.sem
		return nil, err
	}
	var once sync.Once
	return &limitConn{conn, func() { once.Do(func() { <-l.sem }) }}, nil
}

// ---- CRL (hot-reloaded so revocation needs no restart) -------------------

type crlStore struct {
	mu      sync.RWMutex
	revoked map[string]bool
}

func (s *crlStore) isRevoked(serial string) bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.revoked[serial]
}

func (s *crlStore) set(m map[string]bool) {
	s.mu.Lock()
	s.revoked = m
	s.mu.Unlock()
}

// watch reloads the CRL when its mtime changes (default every 60s).
func (s *crlStore) watch(path string, every time.Duration) {
	var lastMod time.Time
	if fi, err := os.Stat(path); err == nil {
		lastMod = fi.ModTime()
	}
	for range time.Tick(every) {
		fi, err := os.Stat(path)
		if err != nil || !fi.ModTime().After(lastMod) {
			continue
		}
		lastMod = fi.ModTime()
		m, err := loadCRL(path)
		if err != nil {
			audit("crl_reload_failed", map[string]any{"file": path, "reason": err.Error()})
			continue
		}
		s.set(m)
		audit("crl_reloaded", map[string]any{"file": path, "revoked": len(m)})
	}
}

// loadCRL parses a PEM or DER CRL and returns the set of revoked serials.
func loadCRL(path string) (map[string]bool, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if block, _ := pem.Decode(raw); block != nil {
		raw = block.Bytes
	}
	crl, err := x509.ParseRevocationList(raw)
	if err != nil {
		return nil, err
	}
	revoked := make(map[string]bool, len(crl.RevokedCertificateEntries))
	for _, rc := range crl.RevokedCertificateEntries {
		revoked[rc.SerialNumber.String()] = true
	}
	return revoked, nil
}

// ---- path safety --------------------------------------------------------

func unsafePath(raw string) bool {
	decoded, err := url.PathUnescape(raw)
	if err != nil {
		return true
	}
	return strings.Contains(raw, "..") || strings.Contains(decoded, "..") ||
		strings.Contains(raw, "\\") || strings.Contains(decoded, "\x00")
}

func newProxy(target *url.URL) *httputil.ReverseProxy {
	return &httputil.ReverseProxy{
		Rewrite: func(pr *httputil.ProxyRequest) {
			pr.SetURL(target)
			pr.Out.Host = target.Host
			// SetURL drops hop-by-hop headers and adds no X-Forwarded-*
			// unless asked — nothing device-identifying leaks upstream.
			pr.Out.Header.Del("Forwarded")
			for h := range pr.Out.Header {
				if strings.HasPrefix(strings.ToLower(h), "x-forwarded-") {
					pr.Out.Header.Del(h)
				}
			}
		},
		FlushInterval: -1, // flush every chunk immediately (SSE)
		ErrorHandler: func(w http.ResponseWriter, r *http.Request, err error) {
			var maxErr *http.MaxBytesError
			if errors.As(err, &maxErr) {
				writeJSON(w, http.StatusRequestEntityTooLarge, map[string]string{"error": "request body too large"})
				return
			}
			log.Printf("upstream error: %v", err) // details to logs, not to clients
			writeJSON(w, http.StatusBadGateway, map[string]string{"error": "upstream error"})
		},
		Transport: &http.Transport{
			ForceAttemptHTTP2:     true,
			MaxIdleConns:          100,
			IdleConnTimeout:       90 * time.Second,
			TLSHandshakeTimeout:   10 * time.Second,
			ResponseHeaderTimeout: 600 * time.Second, // long generations
			TLSClientConfig:       &tls.Config{MinVersion: tls.VersionTLS12},
		},
	}
}

func main() {
	port := env("PORT", "8443")
	certFile := env("TLS_CERT", "../certs/server.crt")
	keyFile := env("TLS_KEY", "../certs/server.key")
	caFile := env("TLS_CA", "../certs/ca.crt")
	maxBody := envInt("MAX_BODY_BYTES", 25*1024*1024)

	allowedDevices := map[string]bool{}
	for _, cn := range strings.Split(os.Getenv("ALLOWED_DEVICES"), ",") {
		if cn = strings.TrimSpace(cn); cn != "" {
			allowedDevices[cn] = true
		}
	}

	caPEM, err := os.ReadFile(caFile)
	if err != nil {
		log.Fatalf("read CA: %v", err)
	}
	caPool := x509.NewCertPool()
	if !caPool.AppendCertsFromPEM(caPEM) {
		log.Fatal("invalid CA certificate")
	}

	crl := &crlStore{}
	if crlPath := os.Getenv("TLS_CRL"); crlPath != "" {
		m, err := loadCRL(crlPath)
		if err != nil {
			log.Fatalf("load CRL: %v", err)
		}
		crl.set(m)
		every := time.Duration(envInt("CRL_RELOAD_SECS", 60)) * time.Second
		go crl.watch(crlPath, every)
		audit("crl_loaded", map[string]any{"file": crlPath, "revoked": len(m), "reload_every": every.String()})
	}

	rl := newLimiter(envInt("RATE_LIMIT_RPM", 120), envInt("RATE_LIMIT_BURST", 30))

	loadExtraUpstreams()
	proxies := make(map[string]*httputil.ReverseProxy, len(upstreams))
	for prefix, raw := range upstreams {
		u, err := url.Parse(raw)
		if err != nil {
			log.Fatalf("parse upstream %s: %v", raw, err)
		}
		proxies[prefix] = newProxy(u)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]bool{"ok": true})
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		device := "unknown"
		if r.TLS != nil && len(r.TLS.PeerCertificates) > 0 {
			device = r.TLS.PeerCertificates[0].Subject.CommonName
		}
		if len(allowedDevices) > 0 && !allowedDevices[device] {
			audit("access_denied", map[string]any{"device": deviceLabel(device), "ip": r.RemoteAddr, "reason": "not_in_allowlist"})
			writeJSON(w, http.StatusForbidden, map[string]string{"error": "device not allowed"})
			return
		}
		if unsafePath(r.URL.EscapedPath()) {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid path"})
			return
		}

		parts := strings.SplitN(strings.TrimPrefix(r.URL.Path, "/"), "/", 2)
		proxy, ok := proxies[parts[0]]
		if !ok {
			writeJSON(w, http.StatusNotFound, map[string]string{"error": "unknown route"})
			return
		}
		if !rl.allow(device) {
			w.Header().Set("Retry-After", "10")
			writeJSON(w, http.StatusTooManyRequests, map[string]string{"error": "rate limit exceeded"})
			return
		}

		// Log only method/path/device — never headers, bodies, or queries.
		if !logMinimal {
			audit("request", map[string]any{"device": deviceLabel(device), "method": r.Method, "path": r.URL.Path})
		}

		r.Body = http.MaxBytesReader(w, r.Body, maxBody)
		rest := "/"
		if len(parts) == 2 {
			rest = "/" + parts[1]
		}
		r.URL.Path = rest
		proxy.ServeHTTP(w, r)
	})

	// FIPS_MODE=1: TLS 1.3 only. Note: Go's TLS 1.3 suite set is fixed and
	// includes ChaCha20; for full FIPS 140-3 build with the BoringCrypto
	// module (GOEXPERIMENT=boringcrypto), which disables non-approved
	// algorithms at the crypto layer. See docs/COMPLIANCE.md.
	fipsMode := os.Getenv("FIPS_MODE") == "1"
	minVer := uint16(tls.VersionTLS13)
	if !fipsMode && os.Getenv("TLS_MIN_VERSION") == "1.2" {
		minVer = tls.VersionTLS12
	}
	tlsCfg := &tls.Config{
		ClientAuth: tls.RequireAndVerifyClientCert,
		ClientCAs:  caPool,
		MinVersion: minVer,
		// Governs the optional TLS 1.2 fallback only (1.3 suites are fixed):
		// ECDHE + AEAD only — no CBC, no static RSA key exchange.
		CipherSuites: []uint16{
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
		},
		CurvePreferences: []tls.CurveID{tls.X25519, tls.CurveP256},
		VerifyPeerCertificate: func(rawCerts [][]byte, chains [][]*x509.Certificate) error {
			if len(chains) == 0 || len(chains[0]) == 0 {
				return nil
			}
			if crl.isRevoked(chains[0][0].SerialNumber.String()) {
				return errors.New("client certificate revoked")
			}
			return nil
		},
	}

	server := &http.Server{
		Addr:              ":" + port,
		Handler:           mux,
		TLSConfig:         tlsCfg,
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       75 * time.Second,
		MaxHeaderBytes:    32 << 10,
		// No WriteTimeout: streams may run for many minutes; the transport's
		// ResponseHeaderTimeout and client disconnects bound each request.
	}

	// Concurrent-connection cap (DoS containment, NIST SC-5).
	base, err := net.Listen("tcp", server.Addr)
	if err != nil {
		log.Fatalf("listen: %v", err)
	}
	maxConns := int(envInt("MAX_CONNS", 500))
	listener := &limitListener{Listener: base, sem: make(chan struct{}, maxConns)}

	audit("startup", map[string]any{
		"port": port, "fips_mode": fipsMode, "min_tls_13": minVer == tls.VersionTLS13,
		"max_conns": maxConns, "upstreams": len(upstreams),
	})
	log.Fatal(server.ServeTLS(listener, certFile, keyFile))
}
