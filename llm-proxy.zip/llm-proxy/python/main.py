"""
llm-proxy (Python) — stateless mTLS reverse proxy for LLM APIs.

- mTLS is enforced by uvicorn (see run.sh): connections without a client
  certificate signed by the configured CA are rejected during the TLS
  handshake, before any request reaches this code.
- Stores NO credentials. Provider API keys (Authorization / x-api-key)
  arrive from the AI/mobile agent on every request and are forwarded verbatim
  upstream. They are never logged and never written to disk.
- Routes by path prefix:
      /anthropic/...  -> https://api.anthropic.com/...
      /openai/...     -> https://api.openai.com/...
      /deepseek/...   -> https://api.deepseek.com/...
- Fully streaming in both directions (SSE-friendly).
- Hardened: path traversal guard, request body cap, per-client rate
  limiting. (uvicorn does not expose the client certificate to the app,
  so rate limiting keys on client IP here; the Node and Go variants key
  on the certificate CN. Revocation is enforced in run.py via CRL.)

Run:  ./run.py   (builds the mTLS + CRL SSL context and starts uvicorn)
"""
import logging
import os
import time
from collections import defaultdict
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.background import BackgroundTask

RATE_LIMIT_RPM = float(os.environ.get("RATE_LIMIT_RPM", "120"))
RATE_LIMIT_BURST = float(os.environ.get("RATE_LIMIT_BURST", "30"))
MAX_BODY_BYTES = int(os.environ.get("MAX_BODY_BYTES", str(25 * 1024 * 1024)))

# Prefix -> upstream base. The proxy forwards the remainder of the path
# verbatim, so the app uses each provider's documented path after the prefix
# (e.g. /zhipu/api/paas/v4/chat/completions). Auth headers pass through
# untouched (Bearer, x-goog-api-key, ...).
UPSTREAMS = {
    # major labs
    "anthropic": "https://api.anthropic.com",
    "openai": "https://api.openai.com",
    "deepseek": "https://api.deepseek.com",
    "gemini": "https://generativelanguage.googleapis.com",
    "mistral": "https://api.mistral.ai",
    "cohere": "https://api.cohere.com",
    "ai21": "https://api.ai21.com",
    "perplexity": "https://api.perplexity.ai",
    "stability": "https://api.stability.ai",
    # China-based
    "dashscope": "https://dashscope-intl.aliyuncs.com",
    "moonshot": "https://api.moonshot.ai",
    "zhipu": "https://open.bigmodel.cn",
    "zai": "https://api.z.ai",
    "siliconflow": "https://api.siliconflow.com",
    # Russia-based
    "yandex": "https://llm.api.cloud.yandex.net",
    "gigachat": "https://api.giga.chat",
    "gigachat-auth": "https://ngw.devices.sberbank.ru:9443",  # OAuth token endpoint
    # embeddings, image & specialized
    "voyage": "https://api.voyageai.com",
    "jina": "https://api.jina.ai",
    "nomic": "https://api-atlas.nomic.ai",
    "recraft": "https://external.api.recraft.ai",
    "upstage": "https://api.upstage.ai",
}

# Operator-configured extra routes, e.g. a workspace-scoped DashScope host:
# EXTRA_UPSTREAMS="myalias=host.example.com,other=host2.example"
# Deploy-time only — clients can never add routes.
import re as _re
for _pair in os.environ.get("EXTRA_UPSTREAMS", "").split(","):
    if "=" not in _pair:
        continue
    _alias, _host = (s.strip() for s in _pair.split("=", 1))
    if _re.fullmatch(r"[a-z0-9-]+", _alias) and _re.fullmatch(r"[A-Za-z0-9.-]+(:\d+)?", _host):
        UPSTREAMS[_alias] = f"https://{_host}"

# Hop-by-hop headers must not be forwarded (RFC 9110 §7.6.1).
HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailer", "transfer-encoding", "upgrade", "proxy-connection",
}

log = logging.getLogger("llm-proxy")
if os.environ.get("LOG_FORMAT") == "json":
    # Structured audit records (NIST AU-3). Message text carries the event;
    # no headers, bodies or queries are ever logged.
    logging.basicConfig(
        level=logging.INFO,
        format='{"ts":"%(asctime)s","evt":"proxy","msg":"%(message)s"}',
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )
else:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.client = httpx.AsyncClient(
        timeout=httpx.Timeout(connect=10.0, read=600.0, write=600.0, pool=10.0),
        limits=httpx.Limits(max_connections=200, max_keepalive_connections=50),
    )
    yield
    await app.state.client.aclose()


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


def _filter_request_headers(request: Request) -> dict:
    headers = {}
    for name, value in request.headers.items():
        lname = name.lower()
        if lname in HOP_BY_HOP or lname in ("host", "content-length"):
            continue
        headers[name] = value
    return headers


def _filter_response_headers(resp: httpx.Response) -> dict:
    return {
        name: value
        for name, value in resp.headers.items()
        if name.lower() not in HOP_BY_HOP and name.lower() != "content-length"
    }


# ---- per-client token bucket (keyed on IP; see module docstring) --------
_buckets: dict[str, list[float]] = defaultdict(lambda: [RATE_LIMIT_BURST, time.monotonic()])


def _rate_limited(key: str) -> bool:
    if RATE_LIMIT_RPM <= 0:
        return False
    bucket = _buckets[key]
    now = time.monotonic()
    bucket[0] = min(RATE_LIMIT_BURST, bucket[0] + (now - bucket[1]) / 60.0 * RATE_LIMIT_RPM)
    bucket[1] = now
    if len(_buckets) > 10_000:  # bound memory under source-address churn
        for k in [k for k, b in _buckets.items() if now - b[1] > 600][:5000]:
            del _buckets[k]
    if bucket[0] < 1:
        return True
    bucket[0] -= 1
    return False


def _unsafe_path(path: str) -> bool:
    return ".." in path or "\\" in path or "\x00" in path


async def _capped_stream(request: Request):
    """Stream the request body upstream while enforcing MAX_BODY_BYTES
    (chunked bodies can lie about Content-Length)."""
    received = 0
    async for chunk in request.stream():
        received += len(chunk)
        if received > MAX_BODY_BYTES:
            raise ValueError("request body too large")
        yield chunk


@app.get("/healthz")
async def healthz():
    return {"ok": True}


@app.api_route(
    "/{provider}/{upstream_path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
)
async def proxy(provider: str, upstream_path: str, request: Request):
    base = UPSTREAMS.get(provider)
    if base is None:
        return JSONResponse(status_code=404, content={"error": "unknown route"})

    if _unsafe_path(upstream_path):
        return JSONResponse(status_code=400, content={"error": "invalid path"})

    client_key = request.client.host if request.client else "unknown"
    if _rate_limited(client_key):
        return JSONResponse(
            status_code=429,
            content={"error": "rate limit exceeded"},
            headers={"Retry-After": "10"},
        )

    declared = int(request.headers.get("content-length") or 0)
    if declared > MAX_BODY_BYTES:
        return JSONResponse(status_code=413, content={"error": "request body too large"})

    url = f"{base}/{upstream_path}"
    client: httpx.AsyncClient = request.app.state.client

    upstream_request = client.build_request(
        method=request.method,
        url=url,
        headers=_filter_request_headers(request),
        params=request.query_params,
        content=_capped_stream(request),  # stream the body, enforcing the cap
    )
    try:
        upstream_response = await client.send(upstream_request, stream=True)
    except ValueError:
        return JSONResponse(status_code=413, content={"error": "request body too large"})
    except httpx.HTTPError:
        # No upstream error details to the client — they can leak topology.
        log.warning("upstream error for %s", provider)
        return JSONResponse(status_code=502, content={"error": "upstream error"})

    # Log only method/path/status — never headers or bodies.
    # LOG_LEVEL=minimal suppresses per-request records entirely.
    if os.environ.get("LOG_LEVEL") != "minimal":
        log.info("%s /%s/%s -> %s", request.method, provider, upstream_path,
                 upstream_response.status_code)

    return StreamingResponse(
        upstream_response.aiter_raw(),  # raw pass-through, SSE chunks intact
        status_code=upstream_response.status_code,
        headers=_filter_response_headers(upstream_response),
        background=BackgroundTask(upstream_response.aclose),
    )
