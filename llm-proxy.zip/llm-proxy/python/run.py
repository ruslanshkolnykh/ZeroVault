#!/usr/bin/env python3
"""
Launcher for the Python proxy. uvicorn's CLI flags cannot express CRL
checking or a TLS-1.3 floor, so this builds the Config, lets it create the
SSL context, then tightens it before serving:

  - CERT_REQUIRED: handshake fails without a client cert signed by the CA
  - optional CRL (TLS_CRL) with VERIFY_CRL_CHECK_LEAF
  - TLS 1.3 minimum by default (TLS_MIN_VERSION=TLSv1.2 for older devices;
    the fallback is restricted to ECDHE+AEAD ciphers)

Env: PORT, CERTS_DIR, TLS_CRL, TLS_MIN_VERSION, RATE_LIMIT_RPM,
     RATE_LIMIT_BURST, MAX_BODY_BYTES (the last three read by main.py).
"""
import os
import ssl

import uvicorn

CERTS = os.environ.get("CERTS_DIR", "../certs")

config = uvicorn.Config(
    "main:app",
    host="0.0.0.0",
    port=int(os.environ.get("PORT", "8443")),
    ssl_certfile=f"{CERTS}/server.crt",
    ssl_keyfile=f"{CERTS}/server.key",
    ssl_ca_certs=f"{CERTS}/ca.crt",
    ssl_cert_reqs=ssl.CERT_REQUIRED,
    timeout_keep_alive=75,
    server_header=False,
    limit_concurrency=200,
    h11_max_incomplete_event_size=32 * 1024,  # cap header block size
)
config.load()

ctx: ssl.SSLContext = config.ssl
FIPS_MODE = os.environ.get("FIPS_MODE") == "1"
if not FIPS_MODE and os.environ.get("TLS_MIN_VERSION") == "TLSv1.2":
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    # TLS 1.2 fallback: ECDHE + AEAD only — no CBC, no static RSA.
    ctx.set_ciphers("ECDHE+AESGCM:ECDHE+CHACHA20")
else:
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    if FIPS_MODE:
        # Python's ssl module cannot restrict TLS 1.3 suites; full FIPS
        # 140-3 requires running against an OpenSSL FIPS provider (which
        # disables ChaCha20 itself). See docs/COMPLIANCE.md.
        print("FIPS_MODE: TLS 1.3 only; pair with an OpenSSL FIPS provider")

crl = os.environ.get("TLS_CRL")
if crl:
    ctx.load_verify_locations(cafile=crl)
    ctx.verify_flags |= ssl.VERIFY_CRL_CHECK_LEAF
    print(f"CRL loaded from {crl}")

uvicorn.Server(config).run()
