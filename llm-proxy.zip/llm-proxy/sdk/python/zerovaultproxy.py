"""
llm-proxy Python SDK (stdlib only, Python 3.9+).

Connects an agent to the llm-proxy gateway over mTLS. The SDK never stores
provider API keys — pass them per request, or supply a `key_provider`
callback that fetches them from your secret store lazily.

    from zerovaultproxy import ZeroVaultProxyClient

    client = ZeroVaultProxyClient(
        proxy_url="https://proxy.example.com:8443",
        cert="client-device.crt", key="client-device.key", ca="ca.crt",
    )
    r = client.request("anthropic", "/v1/messages",
                       api_key=my_key,
                       headers={"anthropic-version": "2023-06-01"},
                       json={"model": "claude-sonnet-4-5", "max_tokens": 100,
                             "messages": [{"role": "user", "content": "hi"}]})
    print(r.json()["content"])

Official SDKs work through the proxy too — see docs/SDK.md ("Using official
SDKs"): point their base_url at client.base_url(provider) and give them an
mTLS-configured HTTP client.
"""
from __future__ import annotations

import http.client
import json as _json
import ssl
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterator, Optional, Union
from urllib.parse import urlsplit

PROVIDERS = [
    "anthropic", "openai", "deepseek", "gemini", "mistral", "cohere", "ai21",
    "perplexity", "stability", "dashscope", "moonshot", "zhipu", "zai",
    "siliconflow", "yandex", "gigachat", "voyage", "jina", "nomic", "recraft", "upstage",
]


class ZeroVaultProxyError(Exception):
    """HTTP error from the proxy or the upstream provider."""

    def __init__(self, status: int, body: str, provider: str, path: str):
        super().__init__(f"zerovaultproxy: {status} from /{provider}{path}")
        self.status = status
        self.body = body
        self.provider = provider
        self.path = path


@dataclass
class ProxyResponse:
    status: int
    headers: Dict[str, str]
    content: bytes

    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return _json.loads(self.content)


@dataclass
class SseEvent:
    event: str
    data: str


def auth_header(provider: str, api_key: str) -> Dict[str, str]:
    """The header carrying the API key for a given provider."""
    if provider == "anthropic":
        return {"x-api-key": api_key}
    if provider == "gemini":
        return {"x-goog-api-key": api_key}
    return {"Authorization": f"Bearer {api_key}"}


class ZeroVaultProxyClient:
    def __init__(
        self,
        proxy_url: str,
        cert: str,
        key: str,
        ca: str,
        password: Optional[str] = None,
        key_provider: Optional[Callable[[str], str]] = None,
        timeout: float = 600.0,
    ):
        """cert/key/ca are file paths (PEM). `ca` is pinned as the only
        trusted issuer for the proxy's server certificate."""
        u = urlsplit(proxy_url)
        if u.scheme != "https":
            raise ValueError("proxy_url must be https://")
        self._host = u.hostname or ""
        self._port = u.port or 443
        self._key_provider = key_provider
        self._timeout = timeout
        ctx = ssl.create_default_context(cafile=ca)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(certfile=cert, keyfile=key, password=password)
        self.ssl_context = ctx  # reusable with httpx / official SDKs

    def base_url(self, provider: str) -> str:
        """Base URL for pointing an official SDK at the proxy."""
        self._check(provider)
        return f"https://{self._host}:{self._port}/{provider}"

    @staticmethod
    def _check(provider: str) -> None:
        import re
        if not re.fullmatch(r"[a-z0-9-]+", provider):  # ASCII-only, no unicode alnum
            raise ValueError(f"invalid provider: {provider}")

    @staticmethod
    def _check_path(path: str) -> None:
        # Reject request-line injection: control chars, whitespace, traversal.
        if any(c in path for c in ("\r", "\n", "\0", " ")) or ".." in path:
            raise ValueError("invalid path")

    def _headers(self, provider: str, headers: Optional[Dict[str, str]],
                 api_key: Optional[str]) -> Dict[str, str]:
        out = dict(headers or {})
        key = api_key or (self._key_provider(provider) if self._key_provider else None)
        if key:
            out.update(auth_header(provider, key))
        return out

    def _connect(self) -> http.client.HTTPSConnection:
        return http.client.HTTPSConnection(
            self._host, self._port, context=self.ssl_context, timeout=self._timeout
        )

    def request(
        self,
        provider: str,
        path: str,
        method: str = "POST",
        headers: Optional[Dict[str, str]] = None,
        json: Any = None,
        content: Union[bytes, str, None] = None,
        api_key: Optional[str] = None,
        raise_on_error: bool = True,
    ) -> ProxyResponse:
        """Raw pass-through request. `path` is the provider's documented
        path (e.g. "/v1/chat/completions")."""
        self._check(provider)
        self._check_path(path)
        hdrs = self._headers(provider, headers, api_key)
        body: Union[bytes, str, None] = content
        if json is not None:
            body = _json.dumps(json)
            hdrs.setdefault("content-type", "application/json")
        conn = self._connect()
        try:
            conn.request(method, f"/{provider}{path if path.startswith('/') else '/' + path}",
                         body=body, headers=hdrs)
            resp = conn.getresponse()
            data = resp.read()
            result = ProxyResponse(resp.status, dict(resp.getheaders()), data)
        finally:
            conn.close()
        if result.status >= 400 and raise_on_error:
            raise ZeroVaultProxyError(result.status, result.text(), provider, path)
        return result

    def stream(
        self,
        provider: str,
        path: str,
        method: str = "POST",
        headers: Optional[Dict[str, str]] = None,
        json: Any = None,
        api_key: Optional[str] = None,
    ) -> Iterator[SseEvent]:
        """Streaming request: yields Server-Sent Events. Set "stream": true
        in the body per the provider's docs."""
        self._check(provider)
        self._check_path(path)
        hdrs = self._headers(provider, headers, api_key)
        hdrs.setdefault("accept", "text/event-stream")
        body = None
        if json is not None:
            body = _json.dumps(json)
            hdrs.setdefault("content-type", "application/json")
        conn = self._connect()
        try:
            conn.request(method, f"/{provider}{path if path.startswith('/') else '/' + path}",
                         body=body, headers=hdrs)
            resp = conn.getresponse()
            if resp.status >= 400:
                raise ZeroVaultProxyError(resp.status, resp.read().decode("utf-8", "replace"),
                                    provider, path)
            event, data = "message", []
            for raw in resp:
                for line in raw.splitlines():
                    text = line.decode("utf-8", "replace").rstrip("\r")
                    if text == "":
                        if data:
                            yield SseEvent(event, "\n".join(data))
                        event, data = "message", []
                    elif text.startswith("event:"):
                        event = text[6:].strip()
                    elif text.startswith("data:"):
                        data.append(text[5:].lstrip(" "))
            if data:
                yield SseEvent(event, "\n".join(data))
        finally:
            conn.close()
