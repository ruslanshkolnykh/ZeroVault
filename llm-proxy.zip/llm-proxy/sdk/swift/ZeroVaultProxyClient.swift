/**
 * llm-proxy Swift/iOS SDK (URLSession, no dependencies).
 *
 * mTLS client for the llm-proxy gateway. The SDK never stores provider API
 * keys — pass them per request, or supply a keyProvider that reads them
 * from the Keychain lazily.
 *
 * Setup: import the device's client-<name>.p12 (from generate-certs.sh)
 * with SecPKCS12Import at enrollment and keep the identity in the Keychain;
 * bundle ca.crt as the pinned trust anchor. See docs/SDK.md.
 */
import Foundation

public enum ZeroVaultProxyErrorKind: Error {
    case httpError(status: Int, body: String, provider: String, path: String)
    case invalidResponse
}

public final class ZeroVaultProxyClient: NSObject {
    public static let providers = [
        "anthropic", "openai", "deepseek", "gemini", "mistral", "cohere",
        "ai21", "perplexity", "stability", "dashscope", "moonshot", "zhipu",
        "zai", "siliconflow", "yandex", "gigachat", "voyage", "jina", "nomic", "recraft", "upstage",
    ]

    private let proxyURL: URL
    private let identity: SecIdentity          // device cert + key (from .p12)
    private let caCertificate: SecCertificate  // pinned proxy CA
    private let keyProvider: ((String) -> String?)?
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.ephemeral   // no shared cookie/cred stores
        config.timeoutIntervalForRequest = 600            // long streaming generations
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    public init(proxyURL: URL, identity: SecIdentity, caCertificate: SecCertificate,
                keyProvider: ((String) -> String?)? = nil) {
        precondition(proxyURL.scheme == "https", "proxyURL must be https")
        self.proxyURL = proxyURL
        self.identity = identity
        self.caCertificate = caCertificate
        self.keyProvider = keyProvider
    }

    /// Base URL for pointing another client library at the proxy.
    public func baseUrl(_ provider: String) -> URL {
        proxyURL.appendingPathComponent(provider)
    }

    /// Header carrying the API key for a given provider.
    public static func authHeader(provider: String, apiKey: String) -> (String, String) {
        switch provider {
        case "anthropic": return ("x-api-key", apiKey)
        case "gemini": return ("x-goog-api-key", apiKey)
        default: return ("Authorization", "Bearer \(apiKey)")
        }
    }

    /// Raw pass-through request. `path` is the provider's documented path.
    /// For SSE streaming, use URLSession's `bytes(for:)` with the same
    /// request and read line by line (see docs/SDK.md).
    public func request(provider: String, path: String, method: String = "POST",
                        json: [String: Any]? = nil, apiKey: String? = nil,
                        headers: [String: String] = [:]) async throws -> (Data, HTTPURLResponse) {
        var url = baseUrl(provider)
        url.append(path: path.hasPrefix("/") ? String(path.dropFirst()) : path)
        var req = URLRequest(url: url)
        req.httpMethod = method
        headers.forEach { req.setValue($0.value, forHTTPHeaderField: $0.key) }
        if let key = apiKey ?? keyProvider?(provider) {
            let (name, value) = Self.authHeader(provider: provider, apiKey: key)
            req.setValue(value, forHTTPHeaderField: name)
        }
        if let json {
            req.httpBody = try JSONSerialization.data(withJSONObject: json)
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        let (data, response) = try await session.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw ZeroVaultProxyErrorKind.invalidResponse }
        guard http.statusCode < 400 else {
            throw ZeroVaultProxyErrorKind.httpError(status: http.statusCode,
                                              body: String(data: data, encoding: .utf8) ?? "",
                                              provider: provider, path: path)
        }
        return (data, http)
    }
}

extension ZeroVaultProxyClient: URLSessionDelegate {
    public func urlSession(_ session: URLSession,
                           didReceive challenge: URLAuthenticationChallenge,
                           completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        switch challenge.protectionSpace.authenticationMethod {
        case NSURLAuthenticationMethodClientCertificate:
            // Present the device identity (mTLS).
            completionHandler(.useCredential,
                              URLCredential(identity: identity, certificates: nil, persistence: .forSession))
        case NSURLAuthenticationMethodServerTrust:
            // Pin the proxy CA: trust ONLY chains anchored at ca.crt.
            guard let trust = challenge.protectionSpace.serverTrust else {
                return completionHandler(.cancelAuthenticationChallenge, nil)
            }
            SecTrustSetAnchorCertificates(trust, [caCertificate] as CFArray)
            SecTrustSetAnchorCertificatesOnly(trust, true)
            var error: CFError?
            if SecTrustEvaluateWithError(trust, &error) {
                completionHandler(.useCredential, URLCredential(trust: trust))
            } else {
                completionHandler(.cancelAuthenticationChallenge, nil)
            }
        default:
            completionHandler(.performDefaultHandling, nil)
        }
    }
}
