/**
 * llm-proxy Kotlin/Android SDK (OkHttp).
 *
 * mTLS client for the llm-proxy gateway. The SDK never stores provider API
 * keys — pass them per request, or supply a keyProvider that reads them
 * from EncryptedSharedPreferences / Android Keystore lazily.
 *
 * Setup: import the device's client-<name>.p12 (from generate-certs.sh)
 * into app-private storage at enrollment, plus ca.crt as the pinned trust
 * anchor. See docs/SDK.md for the full guide.
 *
 * Dependencies: com.squareup.okhttp3:okhttp:4.x
 */
package io.zerovaultproxy.sdk

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.InputStream
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

class ZeroVaultProxyClient(
    private val proxyUrl: String,                 // "https://proxy.example.com:8443"
    p12: InputStream,                             // device identity (PKCS#12)
    p12Password: CharArray,
    caCert: InputStream,                          // ca.crt — pinned trust anchor
    private val keyProvider: ((provider: String) -> String)? = null,
) {
    companion object {
        val PROVIDERS = listOf(
            "anthropic", "openai", "deepseek", "gemini", "mistral", "cohere",
            "ai21", "perplexity", "stability", "dashscope", "moonshot", "zhipu",
            "zai", "siliconflow", "yandex", "gigachat", "voyage", "jina", "nomic", "recraft", "upstage",
        )

        /** Header carrying the API key for a given provider. */
        fun authHeader(provider: String, apiKey: String): Pair<String, String> = when (provider) {
            "anthropic" -> "x-api-key" to apiKey
            "gemini" -> "x-goog-api-key" to apiKey
            else -> "Authorization" to "Bearer $apiKey"
        }
    }

    /** OkHttpClient with the device identity + pinned CA — reusable anywhere. */
    val httpClient: OkHttpClient

    init {
        require(proxyUrl.startsWith("https://")) { "proxyUrl must be https://" }

        val identity = KeyStore.getInstance("PKCS12").apply { load(p12, p12Password) }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
            .apply { init(identity, p12Password) }

        val ca = CertificateFactory.getInstance("X.509")
            .generateCertificate(caCert) as X509Certificate
        val trustStore = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
            load(null, null)
            setCertificateEntry("llm-proxy-ca", ca)   // ONLY this CA is trusted
        }
        val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            .apply { init(trustStore) }

        val ssl = SSLContext.getInstance("TLSv1.3")
            .apply { init(kmf.keyManagers, tmf.trustManagers, null) }

        httpClient = OkHttpClient.Builder()
            .sslSocketFactory(ssl.socketFactory, tmf.trustManagers[0] as X509TrustManager)
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(600, TimeUnit.SECONDS)      // long streaming generations
            .build()
    }

    /** Base URL for pointing an official SDK at the proxy. */
    fun baseUrl(provider: String): String {
        require(provider in PROVIDERS || provider.matches(Regex("[a-z0-9-]+")))
        return "$proxyUrl/$provider"
    }

    /**
     * Raw pass-through request. `path` is the provider's documented path.
     * For SSE streaming set "stream": true in the JSON and read
     * response.body.source() line by line (see docs/SDK.md).
     */
    fun request(
        provider: String,
        path: String,
        jsonBody: String? = null,
        apiKey: String? = null,
        headers: Map<String, String> = emptyMap(),
        method: String = if (jsonBody != null) "POST" else "GET",
    ): Response {
        val builder = Request.Builder()
            .url("${baseUrl(provider)}${if (path.startsWith("/")) path else "/$path"}")
        headers.forEach { (k, v) -> builder.header(k, v) }
        (apiKey ?: keyProvider?.invoke(provider))?.let {
            val (name, value) = authHeader(provider, it)
            builder.header(name, value)
        }
        val body = jsonBody?.toRequestBody("application/json".toMediaType())
        builder.method(method, body)
        return httpClient.newCall(builder.build()).execute()
    }
}
