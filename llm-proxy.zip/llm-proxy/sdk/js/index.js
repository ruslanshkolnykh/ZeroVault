/**
 * llm-proxy JavaScript/TypeScript SDK (Node.js 18+, zero dependencies).
 *
 * Connects an agent to the llm-proxy gateway over mTLS. The SDK never
 * stores provider API keys — pass them per request, or supply a
 * `keyProvider` callback that fetches them from your secret store lazily.
 *
 * See docs/SDK.md for the full guide. Typings in index.d.ts.
 */
'use strict';

const https = require('https');
const { URL } = require('url');

const PROVIDERS = [
  'anthropic', 'openai', 'deepseek', 'gemini', 'mistral', 'cohere', 'ai21',
  'perplexity', 'stability', 'dashscope', 'moonshot', 'zhipu', 'zai',
  'siliconflow', 'yandex', 'gigachat', 'voyage', 'jina', 'nomic', 'recraft', 'upstage',
];

/** Error carrying the proxy/upstream HTTP status and body. */
class ZeroVaultProxyError extends Error {
  constructor(status, body, provider, path) {
    super(`zerovaultproxy: ${status} from /${provider}${path}`);
    this.name = 'ZeroVaultProxyError';
    this.status = status;
    this.body = body;
    this.provider = provider;
    this.path = path;
  }
}

class ZeroVaultProxyClient {
  /**
   * @param {object} opts
   * @param {string} opts.proxyUrl   e.g. "https://proxy.example.com:8443"
   * @param {Buffer|string} opts.cert    device certificate (PEM)
   * @param {Buffer|string} opts.key     device private key (PEM)
   * @param {Buffer|string} opts.ca      the proxy CA (ca.crt) — pinned
   * @param {string} [opts.passphrase]   key passphrase, if encrypted
   * @param {(provider: string) => (string|Promise<string>)} [opts.keyProvider]
   *        called per request to fetch the provider API key; the SDK applies
   *        it with the correct header for that provider.
   * @param {number} [opts.timeoutMs=600000]  per-request timeout (streams included)
   */
  constructor(opts) {
    const u = new URL(opts.proxyUrl);
    if (u.protocol !== 'https:') throw new Error('proxyUrl must be https://');
    this._host = u.hostname;
    this._port = u.port || 443;
    this._keyProvider = opts.keyProvider || null;
    this._timeout = opts.timeoutMs ?? 600_000;
    /** An https.Agent with the device identity — reusable with official SDKs. */
    this.httpsAgent = new https.Agent({
      cert: opts.cert, key: opts.key, ca: opts.ca,
      passphrase: opts.passphrase, keepAlive: true,
    });
  }

  /** Providers this SDK knows the auth scheme for. */
  static get providers() { return [...PROVIDERS]; }

  /** Base URL for pointing an official SDK at the proxy, e.g. baseUrl('openai'). */
  baseUrl(provider) {
    this._check(provider);
    return `https://${this._host}:${this._port}/${provider}`;
  }

  /** The header carrying the API key for a given provider. */
  static authHeader(provider, apiKey) {
    if (provider === 'anthropic') return { 'x-api-key': apiKey };
    if (provider === 'gemini') return { 'x-goog-api-key': apiKey };
    return { authorization: `Bearer ${apiKey}` };
  }

  _check(provider) {
    if (!/^[a-z0-9-]+$/.test(provider)) throw new Error(`invalid provider: ${provider}`);
  }

  /** Reject request-line injection: control chars, whitespace, traversal. */
  _checkPath(path) {
    if (/[\r\n\0 ]/.test(path) || path.includes('..')) throw new Error('invalid path');
  }

  async _headers(provider, headers = {}, apiKey) {
    const out = { ...headers };
    const key = apiKey ?? (this._keyProvider ? await this._keyProvider(provider) : null);
    if (key) Object.assign(out, ZeroVaultProxyClient.authHeader(provider, key));
    return out;
  }

  /**
   * Raw pass-through request. `path` is the provider's documented path
   * (e.g. "/v1/messages"). Returns { status, headers, buffer, text(), json() }.
   * Throws ZeroVaultProxyError on status >= 400 unless opts.throwOnError === false.
   */
  async request(provider, path, opts = {}) {
    this._check(provider);
    const body = opts.json !== undefined ? JSON.stringify(opts.json) : opts.body;
    const headers = await this._headers(provider, opts.headers, opts.apiKey);
    if (opts.json !== undefined && !headers['content-type']) {
      headers['content-type'] = 'application/json';
    }
    const res = await this._send(provider, path, opts.method, headers, body, opts.signal);
    const chunks = [];
    for await (const c of res) chunks.push(c);
    const buffer = Buffer.concat(chunks);
    const result = {
      status: res.statusCode,
      headers: res.headers,
      buffer,
      text: () => buffer.toString('utf8'),
      json: () => JSON.parse(buffer.toString('utf8')),
    };
    if (res.statusCode >= 400 && opts.throwOnError !== false) {
      throw new ZeroVaultProxyError(res.statusCode, result.text(), provider, path);
    }
    return result;
  }

  /**
   * Streaming request: yields Server-Sent Events as { event, data } objects
   * (data is the raw string; JSON.parse it per provider format). Set
   * `"stream": true` in the request body per the provider's docs.
   */
  async *stream(provider, path, opts = {}) {
    this._check(provider);
    const body = opts.json !== undefined ? JSON.stringify(opts.json) : opts.body;
    const headers = await this._headers(provider, opts.headers, opts.apiKey);
    if (opts.json !== undefined && !headers['content-type']) {
      headers['content-type'] = 'application/json';
    }
    headers.accept = headers.accept || 'text/event-stream';
    const res = await this._send(provider, path, opts.method, headers, body, opts.signal);
    if (res.statusCode >= 400) {
      const chunks = [];
      for await (const c of res) chunks.push(c);
      throw new ZeroVaultProxyError(res.statusCode, Buffer.concat(chunks).toString('utf8'), provider, path);
    }
    let buf = '';
    let event = { event: 'message', data: '' };
    for await (const chunk of res) {
      buf += chunk.toString('utf8');
      let idx;
      while ((idx = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, idx).replace(/\r$/, '');
        buf = buf.slice(idx + 1);
        if (line === '') {
          if (event.data !== '') yield { event: event.event, data: event.data.replace(/\n$/, '') };
          event = { event: 'message', data: '' };
        } else if (line.startsWith('event:')) {
          event.event = line.slice(6).trim();
        } else if (line.startsWith('data:')) {
          event.data += line.slice(5).replace(/^ /, '') + '\n';
        } // comments (:) and other fields ignored
      }
    }
    if (event.data !== '') yield { event: event.event, data: event.data.replace(/\n$/, '') };
  }

  _send(provider, path, method = 'POST', headers = {}, body, signal) {
    this._checkPath(path);
    return new Promise((resolve, reject) => {
      const req = https.request({
        host: this._host,
        port: this._port,
        path: `/${provider}${path.startsWith('/') ? path : `/${path}`}`,
        method,
        headers,
        agent: this.httpsAgent,
        timeout: this._timeout,
        signal,
      }, resolve);
      req.on('timeout', () => req.destroy(new Error('zerovaultproxy: request timeout')));
      req.on('error', reject);
      if (body !== undefined) req.write(body);
      req.end();
    });
  }
}

module.exports = { ZeroVaultProxyClient, ZeroVaultProxyError, PROVIDERS };
