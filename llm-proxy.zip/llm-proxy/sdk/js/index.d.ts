import { Agent } from 'https';

export declare const PROVIDERS: string[];

export declare class ZeroVaultProxyError extends Error {
  status: number;
  body: string;
  provider: string;
  path: string;
}

export interface ZeroVaultProxyClientOptions {
  /** e.g. "https://proxy.example.com:8443" */
  proxyUrl: string;
  /** Device certificate (PEM). */
  cert: string | Buffer;
  /** Device private key (PEM). */
  key: string | Buffer;
  /** The proxy CA (ca.crt) — pinned as the only trusted issuer. */
  ca: string | Buffer;
  passphrase?: string;
  /** Fetch a provider API key lazily (e.g. from your secret store). */
  keyProvider?: (provider: string) => string | Promise<string>;
  /** Per-request timeout in ms (default 600000). */
  timeoutMs?: number;
}

export interface RequestOptions {
  method?: string;
  headers?: Record<string, string>;
  /** JSON body (sets content-type automatically). */
  json?: unknown;
  /** Raw body (mutually exclusive with json). */
  body?: string | Buffer;
  /** Provider API key for this request (overrides keyProvider). */
  apiKey?: string;
  signal?: AbortSignal;
  /** Default true: statuses >= 400 throw ZeroVaultProxyError. */
  throwOnError?: boolean;
}

export interface ProxyResponse {
  status: number;
  headers: Record<string, string | string[] | undefined>;
  buffer: Buffer;
  text(): string;
  json(): unknown;
}

export interface SseEvent {
  event: string;
  data: string;
}

export declare class ZeroVaultProxyClient {
  constructor(opts: ZeroVaultProxyClientOptions);
  /** mTLS agent — pass as httpAgent to official OpenAI/Anthropic SDKs. */
  httpsAgent: Agent;
  static readonly providers: string[];
  static authHeader(provider: string, apiKey: string): Record<string, string>;
  baseUrl(provider: string): string;
  request(provider: string, path: string, opts?: RequestOptions): Promise<ProxyResponse>;
  stream(provider: string, path: string, opts?: RequestOptions): AsyncGenerator<SseEvent>;
}
