#!/usr/bin/env node
/**
 * llm-proxy (Node.js) — stateless mTLS reverse proxy for LLM APIs.
 * Hardened build. See SECURITY.md for the threat model.
 *
 * - mTLS at the handshake: only client certs signed by the CA are accepted;
 *   optional CRL and per-device CN allowlist on top.
 * - TLS 1.3 by default (TLS_MIN_VERSION=TLSv1.2 enables a fallback with
 *   AEAD/ECDHE ciphers only, for older Android devices).
 * - Stores NO credentials; provider keys pass through in memory only and
 *   are never logged (query strings are redacted from logs too).
 * - Per-device token-bucket rate limiting and request body size caps to
 *   contain abuse from a stolen device certificate.
 *
 * Env vars:
 *   PORT               listen port                     (default 8443)
 *   TLS_CERT/TLS_KEY   server certificate / key        (default ../certs/...)
 *   TLS_CA             client CA bundle                (default ../certs/ca.crt)
 *   TLS_CRL            optional CRL file (revoked device certs) — watched and
 *                      hot-reloaded (CRL_RELOAD_SECS, default 60) without restart
 *   TLS_MIN_VERSION    TLSv1.3 (default) | TLSv1.2
 *   FIPS_MODE          "1" restricts to TLS 1.3 + AES-GCM suites only (no
 *                      ChaCha20 — not FIPS-approved); run Node with a
 *                      FIPS-validated OpenSSL provider for full FIPS 140-3
 *   LOG_FORMAT         "json" emits structured audit records (NIST AU-3)
 *   LOG_LEVEL          "full" (default) logs per-request access records;
 *                      "minimal" logs security events only (TLS rejections,
 *                      denials, CRL reloads) — no per-request lines at all
 *   LOG_DEVICE_HASH    optional salt: log a salted SHA-256 prefix of the
 *                      device CN instead of the CN itself (pseudonymous logs)
 *   MAX_CONNS          concurrent TLS connection cap (default 500; SC-5)
 *   ALLOWED_DEVICES    optional comma-separated cert CNs; empty = any CA-signed cert
 *   RATE_LIMIT_RPM     sustained requests/min per device (default 120; 0 disables)
 *   RATE_LIMIT_BURST   burst size per device            (default 30)
 *   MAX_BODY_BYTES     request body cap                 (default 26214400 = 25 MB)
 */
'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');

const CERT_DIR = path.join(__dirname, '..', 'certs');
const PORT = Number(process.env.PORT || 8443);
const RATE_LIMIT_RPM = Number(process.env.RATE_LIMIT_RPM ?? 120);
const RATE_LIMIT_BURST = Number(process.env.RATE_LIMIT_BURST ?? 30);
const MAX_BODY_BYTES = Number(process.env.MAX_BODY_BYTES ?? 25 * 1024 * 1024);
const ALLOWED_DEVICES = new Set(
  (process.env.ALLOWED_DEVICES || '').split(',').map((s) => s.trim()).filter(Boolean)
);

// Prefix -> upstream host. The proxy forwards the remainder of the path
// verbatim, so the app uses each provider's documented path after the
// prefix (e.g. /zhipu/api/paas/v4/chat/completions). Auth headers pass
// through untouched, so provider-specific schemes (x-goog-api-key for
// Gemini, Bearer for the rest) just work.
const UPSTREAMS = {
  // major labs
  anthropic: 'api.anthropic.com',
  openai: 'api.openai.com',
  deepseek: 'api.deepseek.com',
  gemini: 'generativelanguage.googleapis.com',
  mistral: 'api.mistral.ai',
  cohere: 'api.cohere.com',
  ai21: 'api.ai21.com',
  perplexity: 'api.perplexity.ai',
  stability: 'api.stability.ai',
  // China-based
  dashscope: 'dashscope-intl.aliyuncs.com',
  moonshot: 'api.moonshot.ai',
  zhipu: 'open.bigmodel.cn',
  zai: 'api.z.ai',
  siliconflow: 'api.siliconflow.com',
  // Russia-based
  yandex: 'llm.api.cloud.yandex.net',
  gigachat: 'api.giga.chat',
  'gigachat-auth': 'ngw.devices.sberbank.ru:9443', // OAuth token endpoint
  // embeddings, image & specialized
  voyage: 'api.voyageai.com',
  jina: 'api.jina.ai',
  nomic: 'api-atlas.nomic.ai',
  recraft: 'external.api.recraft.ai',
  upstage: 'api.upstage.ai',
};

// Operator-configured extra routes (e.g. a workspace-scoped DashScope
// endpoint): EXTRA_UPSTREAMS="myalias=host.example.com,other=host2.example"
// Set by the operator at deploy time — clients can never add routes, so
// the proxy stays a closed allowlist, never an open proxy.
for (const pair of (process.env.EXTRA_UPSTREAMS || '').split(',')) {
  const [alias, host] = pair.split('=').map((s) => s && s.trim());
  if (!alias || !host) continue;
  if (!/^[a-z0-9-]+$/.test(alias) || !/^[a-z0-9.-]+(:\d+)?$/i.test(host)) {
    console.warn(`ignoring invalid EXTRA_UPSTREAMS entry: ${pair}`);
    continue;
  }
  UPSTREAMS[alias] = host;
}

// Hop-by-hop headers must not be forwarded (RFC 9110 §7.6.1).
const HOP_BY_HOP = new Set([
  'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
  'te', 'trailer', 'transfer-encoding', 'upgrade', 'proxy-connection',
  'expect',
]);

function filterHeaders(headers, targetHost) {
  const out = {};
  for (const [k, v] of Object.entries(headers)) {
    const key = k.toLowerCase();
    if (HOP_BY_HOP.has(key) || key === 'host') continue;
    // Never forward proxy/edge metadata upstream.
    if (key.startsWith('x-forwarded-') || key === 'forwarded') continue;
    out[k] = v;
  }
  out.host = targetHost;
  return out;
}

/** Reject any path that could change meaning after normalization. */
function unsafePath(rawUrl) {
  let decoded;
  try {
    decoded = decodeURIComponent(rawUrl);
  } catch {
    return true; // malformed percent-encoding
  }
  return rawUrl.includes('..') || decoded.includes('..') ||
         rawUrl.includes('\\') || decoded.includes('\0');
}

// ---- per-device token bucket -------------------------------------------
const buckets = new Map(); // CN -> { tokens, last }
function rateLimited(device) {
  if (!RATE_LIMIT_RPM) return false;
  const now = Date.now();
  let b = buckets.get(device);
  if (!b) { b = { tokens: RATE_LIMIT_BURST, last: now }; buckets.set(device, b); }
  b.tokens = Math.min(RATE_LIMIT_BURST, b.tokens + ((now - b.last) / 60000) * RATE_LIMIT_RPM);
  b.last = now;
  if (b.tokens < 1) return true;
  b.tokens -= 1;
  return false;
}
setInterval(() => { // drop idle buckets so the map cannot grow unbounded
  const cutoff = Date.now() - 10 * 60_000;
  for (const [k, b] of buckets) if (b.last < cutoff) buckets.delete(k);
}, 60_000).unref();

// ---- TLS ----------------------------------------------------------------
const FIPS_MODE = process.env.FIPS_MODE === '1';
const minVersion = (!FIPS_MODE && process.env.TLS_MIN_VERSION === 'TLSv1.2') ? 'TLSv1.2' : 'TLSv1.3';
// FIPS mode: TLS 1.3 only, AES-GCM only (ChaCha20-Poly1305 is not
// FIPS-approved). Otherwise: 1.3 suites plus an ECDHE+AEAD-only 1.2 fallback.
const CIPHERS = FIPS_MODE
  ? ['TLS_AES_256_GCM_SHA384', 'TLS_AES_128_GCM_SHA256']
  : ['TLS_AES_256_GCM_SHA384', 'TLS_CHACHA20_POLY1305_SHA256', 'TLS_AES_128_GCM_SHA256',
     'ECDHE-ECDSA-AES256-GCM-SHA384', 'ECDHE-ECDSA-CHACHA20-POLY1305',
     'ECDHE-ECDSA-AES128-GCM-SHA256', 'ECDHE-RSA-AES256-GCM-SHA384',
     'ECDHE-RSA-CHACHA20-POLY1305', 'ECDHE-RSA-AES128-GCM-SHA256'];

const CRL_PATH = process.env.TLS_CRL || null;
function buildTlsOptions() {
  const opts = {
    cert: fs.readFileSync(process.env.TLS_CERT || path.join(CERT_DIR, 'server.crt')),
    key: fs.readFileSync(process.env.TLS_KEY || path.join(CERT_DIR, 'server.key')),
    ca: fs.readFileSync(process.env.TLS_CA || path.join(CERT_DIR, 'ca.crt')),
    requestCert: true,          // ask the client for a certificate...
    rejectUnauthorized: true,   // ...and refuse the connection without a valid one
    minVersion,
    ciphers: CIPHERS.join(':'),
    honorCipherOrder: true,
  };
  if (CRL_PATH) opts.crl = fs.readFileSync(CRL_PATH);
  return opts;
}
const tlsOptions = buildTlsOptions();

// ---- structured audit logging (NIST AU-3: who, what, when, outcome) ------
// Never logged in ANY mode: headers, bodies, query strings, API keys.
const JSON_LOGS = process.env.LOG_FORMAT === 'json';
const LOG_MINIMAL = process.env.LOG_LEVEL === 'minimal'; // security events only
const DEVICE_HASH_SALT = process.env.LOG_DEVICE_HASH || null;

function audit(evt, fields) {
  const ts = new Date().toISOString();
  if (JSON_LOGS) console.log(JSON.stringify({ ts, evt, ...fields }));
  else console.log(`${ts} ${evt} ${Object.entries(fields).map(([k, v]) => `${k}=${v}`).join(' ')}`);
}

/** Pseudonymize the device CN when LOG_DEVICE_HASH is set. */
function deviceLabel(cn) {
  if (!DEVICE_HASH_SALT) return cn;
  return require('crypto').createHash('sha256')
    .update(DEVICE_HASH_SALT + cn).digest('hex').slice(0, 12);
}

function deny(res, status, error) {
  if (!res.headersSent) {
    res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  }
  res.end(JSON.stringify({ error }));
}

const server = https.createServer(tlsOptions, (req, res) => {
  const peer = req.socket.getPeerCertificate();
  const deviceCN = peer?.subject?.CN || 'unknown';

  // Optional application-layer allowlist on top of CA validation.
  if (ALLOWED_DEVICES.size && !ALLOWED_DEVICES.has(deviceCN)) {
    audit('access_denied', { device: deviceLabel(deviceCN), ip: req.socket.remoteAddress, reason: 'not_in_allowlist' });
    return deny(res, 403, 'device not allowed');
  }

  if (req.url === '/healthz') {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ ok: true }));
  }

  if (unsafePath(req.url)) return deny(res, 400, 'invalid path');

  const match = req.url.match(/^\/([a-z0-9-]+)(\/.*)?$/);
  if (!match || !UPSTREAMS[match[1]]) return deny(res, 404, 'unknown route');

  if (rateLimited(deviceCN)) {
    res.setHeader('retry-after', '10');
    return deny(res, 429, 'rate limit exceeded');
  }

  // Enforce the body cap on declared length up front...
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > MAX_BODY_BYTES) return deny(res, 413, 'request body too large');

  // "host" or "host:port" (e.g. GigaChat's OAuth endpoint on :9443)
  const [targetHost, targetPort] = UPSTREAMS[match[1]].split(':');
  const logPath = (match[2] || '/').split('?')[0]; // never log query strings

  const upstreamReq = https.request({
    host: targetHost,
    port: Number(targetPort || 443),
    method: req.method,
    path: match[2] || '/',
    headers: filterHeaders(req.headers, UPSTREAMS[match[1]]), // Host incl. port
    timeout: 600_000, // long-running streams (10 min)
  }, (upstreamRes) => {
    const respHeaders = { ...upstreamRes.headers };
    for (const k of Object.keys(respHeaders)) {
      if (HOP_BY_HOP.has(k.toLowerCase())) delete respHeaders[k];
    }
    res.writeHead(upstreamRes.statusCode, respHeaders);
    upstreamRes.pipe(res); // streams SSE chunk-by-chunk
    upstreamRes.on('end', () => {
      if (LOG_MINIMAL) return; // minimal mode: no per-request access records
      audit('request', { device: deviceLabel(deviceCN), method: req.method, path: `/${match[1]}${logPath}`, status: upstreamRes.statusCode });
    });
  });

  upstreamReq.on('timeout', () => upstreamReq.destroy(new Error('upstream timeout')));
  upstreamReq.on('error', () => {
    // No upstream error details to the client — they can leak topology.
    if (!res.headersSent) deny(res, 502, 'upstream error');
    else res.destroy();
  });

  // ...and enforce it on the actual stream (chunked bodies lie about length).
  let received = 0;
  req.on('data', (chunk) => {
    received += chunk.length;
    if (received > MAX_BODY_BYTES) {
      upstreamReq.destroy();
      deny(res, 413, 'request body too large');
      req.destroy();
    }
  });

  res.on('close', () => { // client hung up mid-stream: stop paying upstream
    if (!res.writableEnded) upstreamReq.destroy();
  });

  req.pipe(upstreamReq);
});

// A TLS handshake without a valid client cert never reaches the request
// handler; log it so revoked/foreign devices are visible.
server.on('tlsClientError', (err, socket) => {
  audit('tls_rejected', { ip: socket.remoteAddress, reason: err.message });
});

// Concurrent-connection cap (DoS containment, NIST SC-5).
server.maxConnections = Number(process.env.MAX_CONNS || 500);

// Hot-reload the CRL so revocation takes effect without a restart (~60s).
if (CRL_PATH) {
  const interval = Number(process.env.CRL_RELOAD_SECS || 60) * 1000;
  fs.watchFile(CRL_PATH, { interval }, () => {
    try {
      server.setSecureContext(buildTlsOptions());
      audit('crl_reloaded', { file: CRL_PATH });
    } catch (err) {
      audit('crl_reload_failed', { file: CRL_PATH, reason: err.code || err.message });
    }
  });
}

// Node's default requestTimeout (300 s) would kill long generations; the
// upstream timeout above is the real guard. Header timeouts stay tight to
// resist slowloris.
server.requestTimeout = 0;
server.headersTimeout = 30_000;
server.keepAliveTimeout = 75_000;
server.maxHeadersCount = 100;

server.listen(PORT, () => {
  audit('startup', {
    port: PORT, min_tls: minVersion, fips_mode: FIPS_MODE,
    crl: CRL_PATH || 'none', upstreams: Object.keys(UPSTREAMS).length,
  });
});
